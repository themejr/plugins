<?php
/**
 * Elementor Global init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Mysouk
 */

namespace Mysouk\Addons\Elementor;

use \Elementor\Controls_Manager;

/**
 * Integrate with Elementor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Page_Settings {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		if ( ! class_exists( '\Elementor\Core\DocumentTypes\PageBase' ) ) {
			return;
		}

		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'enqueue_styles' ) );

		add_action( 'elementor/element/wp-page/document_settings/after_section_end', array( $this, 'add_new_page_settings_section' ) );

		add_action( 'elementor/document/after_save', array( $this, 'save_post_meta' ), 10, 2 );

		add_action( 'save_post', array( $this, 'save_elementor_settings' ), 10, 3 );

	}


	/**
	 * Preview Elementor Page
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 'reload_elementor', MYSOUK_ADDONS_URL . "/assets/js/admin/reload-elementor.js", array( 'jquery' ), '20210308', true );
	}

	/**
	 * Inline Style
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_styles() {
		wp_add_inline_style( 'elementor-editor', '#elementor-panel .elementor-control-hide_title{display:none}' );
	}

	/**
	 * Add settings to Elementor page settings
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function add_new_page_settings_section( \Elementor\Core\DocumentTypes\PageBase $page ) {
		// Header
		$page->start_controls_section(
			'section_header_settings',
			[
				'label' => esc_html__( 'Header Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);


		$page->add_control(
			'souk_hide_header_section',
			[
				'label'        => esc_html__( 'Hide Header Section', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''

			]
		);

		$page->add_control(
			'souk_hide_campain_bar',
			[
				'label'        => esc_html__( 'Hide Campain Bar', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''

			]
		);

		$page->add_control(
			'souk_header_layout',
			[
				'label'       => esc_html__( 'Header Layout', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'default' => esc_html__( 'Default', 'mysouk' ),
					'v1'      => esc_html__('Header v1', 'mysouk'),
					'v2'      => esc_html__('Header v2', 'mysouk'),
					'v3'      => esc_html__('Header v3', 'mysouk'),
					'v4'      => esc_html__('Header v4', 'mysouk'),
					'v5'      => esc_html__('Header v5', 'mysouk'),
					'v6'      => esc_html__('Header v6', 'mysouk'),
					'v7'      => esc_html__('Header v7', 'mysouk'),
					'v8'      => esc_html__('Header v8', 'mysouk'),
					'v9'      => esc_html__('Header v9', 'mysouk'),
					'v10'     => esc_html__('Header v10', 'mysouk'),
					'v11'     => esc_html__('Header v11', 'mysouk'),
				],
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_header_background',
			[
				'label'       => esc_html__( 'Header Background', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'default'     => esc_html__( 'Default', 'mysouk' ),
					'transparent' => esc_html__( 'Transparent', 'mysouk' ),
				],
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_header_text_color',
			[
				'label'       => esc_html__( 'Text Color', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default' => esc_html__( 'Default', 'mysouk' ),
					'dark'    => esc_html__( 'Dark', 'mysouk' ),
					'light'   => esc_html__( 'Light', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
				'condition'   => [
					'souk_header_background' => 'transparent',
				],
			]
		);

		$page->add_control(
			'souk_hide_header_border',
			[
				'label'        => esc_html__( 'Hide Border Bottom', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''

			]
		);

		$page->add_control(
			'souk_header_v4_bottom_spacing_bottom',
			[
				'label'       => esc_html__( 'Header V4 Spacing', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default' => esc_html__( 'Default', 'mysouk' ),
					'custom'    => esc_html__( 'Custom', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_header_bottom_spacing_bottom',
			[
				'label'     => esc_html__( 'Spacing', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .header-v4 .site-header .header-bottom' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'souk_header_v4_bottom_spacing_bottom' => 'custom',
				],
			]
		);

		$page->add_control(
			'souk_header_primary_menu',
			[
				'label'       => esc_html__( 'Primary Menu', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => $this->get_menus(),
				'default'     => '0',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_department_menu_display',
			[
				'label'       => esc_html__( 'Department Menu Display', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default'    => esc_html__( 'On Hover', 'mysouk' ),
					'onpageload' => esc_html__( 'On Page Load', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_department_menu_display_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .header-department.show_menu_department .department-content' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'souk_department_menu_display' => 'onpageload',
				],
			]
		);

		$page->end_controls_section();

		// Content
		$page->start_controls_section(
			'section_content_settings',
			[
				'label' => esc_html__( 'Content Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$page->add_control(
			'souk_content_width',
			[
				'label'       => esc_html__( 'Content Width', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					''      => esc_html__( 'Normal', 'mysouk' ),
					'large' => esc_html__( 'Large', 'mysouk' ),
				),
				'default'     => '',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_content_top_spacing',
			[
				'label'       => esc_html__( 'Top Spacing', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default' => esc_html__( 'Default', 'mysouk' ),
					'no'      => esc_html__( 'No spacing', 'mysouk' ),
					'custom'  => esc_html__( 'Custom', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_content_top_padding',
			[
				'label'     => esc_html__( 'Spacing', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .site-content.custom-top-spacing' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'souk_content_top_spacing' => 'custom',
				],
			]
		);
		$page->add_control(
			'souk_content_bottom_spacing',
			[
				'label'       => esc_html__( 'Bottom Spacing', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default' => esc_html__( 'Default', 'mysouk' ),
					'no'      => esc_html__( 'No spacing', 'mysouk' ),
					'custom'  => esc_html__( 'Custom', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_content_bottom_padding',
			[
				'label'     => esc_html__( 'Spacing', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .site-content.custom-bottom-spacing' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'souk_content_bottom_spacing' => 'custom',
				],
			]
		);

		$page->end_controls_section();

		// Page Header
		$page->start_controls_section(
			'section_page_header_settings',
			[
				'label' => esc_html__( 'Page Header Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$page->add_control(
			'souk_hide_page_header',
			[
				'label'        => esc_html__( 'Hide Page Header', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''

			]
		);

		$page->add_control(
			'souk_hide_title',
			[
				'label'        => esc_html__( 'Hide Title', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''
			]
		);

		$page->add_control(
			'souk_hide_breadcrumb',
			[
				'label'        => esc_html__( 'Hide Breadcrumb', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''
			]
		);

		$page->add_control(
			'souk_page_header_layout',
			[
				'label'       => esc_html__( 'Layout', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default'  => esc_html__( 'Default', 'mysouk' ),
					'layout-1' => esc_html__( 'Layout 1', 'mysouk' ),
					'layout-2' => esc_html__( 'Layout 2', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_page_header_image',
			[
				'label'     => esc_html__( 'Image', 'mysouk' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [],
				'selectors' => [
					'{{WRAPPER}} #page-header.page-header--layout-2 .featured-image' => 'background-image: url("{{URL}}");',
				],
				'condition'   => [
					'souk_page_header_layout' => 'layout-2',
				],
			]
		);

		$page->add_control(
			'souk_page_header_spacing',
			[
				'label'       => esc_html__( 'Spacing', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default' => esc_html__( 'Default', 'mysouk' ),
					'custom'  => esc_html__( 'Custom', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_page_header_top_padding',
			[
				'label'     => esc_html__( 'Top Spacing', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} #page-header.page-header--layout-1 .page-header__title.custom-spacing' => 'padding-top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} #page-header.page-header--layout-2' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'souk_page_header_spacing' => 'custom',
				],
			]
		);

		$page->add_control(
			'souk_page_header_bottom_padding',
			[
				'label'     => esc_html__( 'Bottom Spacing', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} #page-header.page-header--layout-1 .page-header__title.custom-spacing' => 'padding-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} #page-header.page-header--layout-2' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'souk_page_header_spacing' => 'custom',
				],
			]
		);

		$page->end_controls_section();

		// Boxed
		$page->start_controls_section(
			'section_boxed_layout_settings',
			[
				'label' => esc_html__( 'Boxed Layout Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);
		$page->add_control(
			'souk_disable_page_boxed',
			[
				'label'        => esc_html__( 'Disable Boxed Layout', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''

			]
		);
		$page->add_control(
			'souk_page_boxed_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}.mysouk-boxed-layout' => 'background-color: {{VALUE}};',
				],
			]
		);

		$page->add_control(
			'souk_page_boxed_bg_image',
			[
				'label'     => esc_html__( 'Background Image', 'mysouk' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [],
				'selectors' => [
					'{{WRAPPER}}.mysouk-boxed-layout' => 'background-image: url("{{URL}}");',
				],
			]
		);

		$page->add_control(
			'souk_page_boxed_bg_horizontal',
			[
				'label'       => esc_html__( 'Background Horizontal', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					''       => esc_html__( 'Default', 'mysouk' ),
					'left'   => esc_html__( 'Left', 'mysouk' ),
					'center' => esc_html__( 'Center', 'mysouk' ),
					'right'  => esc_html__( 'Right', 'mysouk' ),
				),
				'default'     => '',
				'label_block' => true,
				'selectors'   => [
					'{{WRAPPER}}.mysouk-boxed-layout' => 'background-position-x:  {{VALUE}};',
				],
			]
		);

		$page->add_control(
			'souk_page_boxed_bg_vertical',
			[
				'label'       => esc_html__( 'Background Vertical', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					''       => esc_html__( 'Default', 'mysouk' ),
					'top'    => esc_html__( 'Top', 'mysouk' ),
					'center' => esc_html__( 'Center', 'mysouk' ),
					'bottom' => esc_html__( 'Bottom', 'mysouk' ),
				),
				'default'     => '',
				'label_block' => true,
				'selectors'   => [
					'{{WRAPPER}}.mysouk-boxed-layout' => 'background-position-y:  {{VALUE}};',
				],
			]
		);

		$page->add_control(
			'souk_page_boxed_bg_repeat',
			[
				'label'       => esc_html__( 'Background Repeat', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					''          => esc_html__( 'Default', 'mysouk' ),
					'no-repeat' => esc_html__( 'No Repeat', 'mysouk' ),
					'repeat'    => esc_html__( 'Repeat', 'mysouk' ),
					'repeat-y'  => esc_html__( 'Repeat Vertical', 'mysouk' ),
					'repeat-x'  => esc_html__( 'Repeat Horizontal', 'mysouk' ),
				),
				'default'     => '',
				'label_block' => true,
				'selectors'   => [
					'{{WRAPPER}}.mysouk-boxed-layout' => 'background-repeat:  {{VALUE}};',
				],
			]
		);

		$page->add_control(
			'souk_page_boxed_bg_attachment',
			[
				'label'       => esc_html__( 'Background Attachment', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					''       => esc_html__( 'Default', 'mysouk' ),
					'scroll' => esc_html__( 'Scroll', 'mysouk' ),
					'fixed'  => esc_html__( 'Fixed', 'mysouk' ),
				),
				'default'     => '',
				'label_block' => true,
				'selectors'   => [
					'{{WRAPPER}}.mysouk-boxed-layout' => 'background-attachment:  {{VALUE}};',
				],
			]
		);

		$page->add_control(
			'souk_page_boxed_bg_size',
			[
				'label'       => esc_html__( 'Background Size', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					''        => esc_html__( 'Default', 'mysouk' ),
					'auto'    => esc_html__( 'Auto', 'mysouk' ),
					'cover'   => esc_html__( 'Cover', 'mysouk' ),
					'contain' => esc_html__( 'Contain', 'mysouk' ),
				),
				'default'     => '',
				'label_block' => true,
				'selectors'   => [
					'{{WRAPPER}}.mysouk-boxed-layout' => 'background-size:  {{VALUE}};',
				],
			]
		);

		$page->end_controls_section();

		$page->start_controls_section(
			'section_footer_settings',
			[
				'label' => esc_html__( 'Footer Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$page->add_control(
			'souk_hide_footer_section',
			[
				'label'        => esc_html__( 'Hide Footer Section', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '',

			]
		);

		$page->add_control(
			'souk_footer_section_border_top',
			[
				'label'        => esc_html__( 'Footer Border', 'mysouk' ),
				'type'         => Controls_Manager::SELECT,
				'options'     => array(
					'default' => esc_html__( 'Default', 'mysouk' ),
					'0'  => esc_html__( 'Hide', 'mysouk' ),
					'1'  => esc_html__( 'Show', 'mysouk' ),
				),
				'default'      => 'default',
				'label_block' => true,

			]
		);

		$page->add_control(
			'souk_footer_section_border_color',
			[
				'label'       => esc_html__( 'Footer Border Color', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'default' => esc_html__( 'Default', 'mysouk' ),
					'custom'  => esc_html__( 'Custom', 'mysouk' ),
				),
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$page->add_control(
			'souk_footer_section_custom_border_color',
			[
				'label'     => esc_html__( 'Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'souk_footer_section_border_color' => 'custom',
				],
			]
		);

		$page->end_controls_section();

		// Mobile Version
		$page->start_controls_section(
			'section_mobile_settings',
			[
				'label' => esc_html__( 'Mobile Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);


		$page->add_control(
			'souk_hide_navigation_bar_mobile',
			[
				'label'        => esc_html__( 'Hide Navigation Bar', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => ''

			]
		);

		$page->end_controls_section();
	}

	/**
	 * Save post meta when save page settings in Elementor
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function save_post_meta( $el, $data ) {
		if ( ! isset( $data['settings'] ) ) {
			return;
		}

		$settings = $data['settings'];
		$post_id  = $el->get_post()->ID;

		// Header

		$header_section = isset( $settings['souk_hide_header_section'] ) ? $settings['souk_hide_header_section'] : '0';
		update_post_meta( $post_id, 'souk_hide_header_section', $header_section );

		$campain_bar = isset( $settings['souk_hide_campain_bar'] ) ? $settings['souk_hide_campain_bar'] : '0';
		update_post_meta( $post_id, 'souk_hide_campain_bar', $campain_bar );

		$header_layout = isset( $settings['souk_header_layout'] ) ? $settings['souk_header_layout'] : 'default';
		update_post_meta( $post_id, 'souk_header_layout', $header_layout );

		$header_background = isset( $settings['souk_header_background'] ) ? $settings['souk_header_background'] : 'default';
		update_post_meta( $post_id, 'souk_header_background', $header_background );

		$header_text_color = isset( $settings['souk_header_text_color'] ) ? $settings['souk_header_text_color'] : 'default';
		update_post_meta( $post_id, 'souk_header_text_color', $header_text_color );

		$page_header = isset( $settings['souk_hide_header_border'] ) ? $settings['souk_hide_header_border'] : false;
		update_post_meta( $post_id, 'souk_hide_header_border', $page_header );

		$souk_header_v4_bottom_spacing_bottom = isset( $settings['souk_header_v4_bottom_spacing_bottom'] ) ? $settings['souk_header_v4_bottom_spacing_bottom'] : 'default';
		update_post_meta( $post_id, 'souk_header_v4_bottom_spacing_bottom', $souk_header_v4_bottom_spacing_bottom );

		if ( isset( $settings['souk_header_bottom_spacing_bottom'] ) ) {
			update_post_meta( $post_id, 'souk_header_bottom_spacing_bottom', $settings['souk_header_bottom_spacing_bottom']['size'] );
		}

		$header_layout = isset( $settings['souk_header_primary_menu'] ) ? $settings['souk_header_primary_menu'] : '0';
		update_post_meta( $post_id, 'souk_header_primary_menu', $header_layout );

		$show_menu_department = isset( $settings['souk_department_menu_display'] ) ? $settings['souk_department_menu_display'] : 'default';
		update_post_meta( $post_id, 'souk_department_menu_display', $show_menu_department );

		if ( isset( $settings['souk_department_menu_display_spacing'] ) ) {
			update_post_meta( $post_id, 'souk_department_menu_display_spacing', $settings['souk_department_menu_display_spacing']['size'] );
		}

		// Content
		$content_width = isset( $settings['souk_content_width'] ) ? $settings['souk_content_width'] : '';
		update_post_meta( $post_id, 'souk_content_width', $content_width );

		$content_top_spacing = isset( $settings['souk_content_top_spacing'] ) ? $settings['souk_content_top_spacing'] : 'default';
		update_post_meta( $post_id, 'souk_content_top_spacing', $content_top_spacing );

		if ( isset( $settings['souk_content_top_padding'] ) ) {
			update_post_meta( $post_id, 'souk_content_top_padding', $settings['souk_content_top_padding']['size'] );
		}
		$content_bottom_spacing = isset( $settings['souk_content_bottom_spacing'] ) ? $settings['souk_content_bottom_spacing'] : 'default';
		update_post_meta( $post_id, 'souk_content_bottom_spacing', $content_bottom_spacing );
		if ( isset( $settings['souk_content_bottom_padding'] ) ) {
			update_post_meta( $post_id, 'souk_content_bottom_padding', $settings['souk_content_bottom_padding']['size'] );
		}

		// Page Header
		$page_header = isset( $settings['souk_hide_page_header'] ) ? $settings['souk_hide_page_header'] : false;
		update_post_meta( $post_id, 'souk_hide_page_header', $page_header );

		$hide_title = isset( $settings['souk_hide_title'] ) ? $settings['souk_hide_title'] : false;
		update_post_meta( $post_id, 'souk_hide_title', $hide_title );

		$hide_breadcrumb = isset( $settings['souk_hide_breadcrumb'] ) ? $settings['souk_hide_breadcrumb'] : false;
		update_post_meta( $post_id, 'souk_hide_breadcrumb', $hide_breadcrumb );

		$souk_page_header_layout = isset( $settings['souk_page_header_layout'] ) ? $settings['souk_page_header_layout'] : 'default';
		update_post_meta( $post_id, 'souk_page_header_layout', $souk_page_header_layout );

		$souk_page_header_image = isset( $settings['souk_page_header_image'] ) ? $settings['souk_page_header_image']['id'] : '';
		update_post_meta( $post_id, 'souk_page_header_image', $souk_page_header_image );

		$page_header_spacing = isset( $settings['souk_page_header_spacing'] ) ? $settings['souk_page_header_spacing'] : 'default';
		update_post_meta( $post_id, 'souk_page_header_spacing', $page_header_spacing );

		if ( isset( $settings['souk_page_header_top_padding'] ) ) {
			update_post_meta( $post_id, 'souk_page_header_top_padding', $settings['souk_page_header_top_padding']['size'] );
		}
		if ( isset( $settings['souk_page_header_bottom_padding'] ) ) {
			update_post_meta( $post_id, 'souk_page_header_bottom_padding', $settings['souk_page_header_bottom_padding']['size'] );
		}

		// Boxed Layout
		$disable_boxed_layout = isset( $settings['souk_disable_page_boxed'] ) ? $settings['souk_disable_page_boxed'] : false;
		update_post_meta( $post_id, 'souk_disable_page_boxed', $disable_boxed_layout );

		$page_boxed_bg_color = isset( $settings['souk_page_boxed_bg_color'] ) ? $settings['souk_page_boxed_bg_color'] : '';
		update_post_meta( $post_id, 'souk_page_boxed_bg_color', $page_boxed_bg_color );

		$page_boxed_bg_image = isset( $settings['souk_page_boxed_bg_image'] ) ? $settings['souk_page_boxed_bg_image']['id'] : '';
		update_post_meta( $post_id, 'souk_page_boxed_bg_image', $page_boxed_bg_image );

		$page_boxed_bg_horizontal = isset( $settings['souk_page_boxed_bg_horizontal'] ) ? $settings['souk_page_boxed_bg_horizontal'] : '';
		update_post_meta( $post_id, 'souk_page_boxed_bg_horizontal', $page_boxed_bg_horizontal );

		$page_boxed_bg_vertical = isset( $settings['souk_page_boxed_bg_vertical'] ) ? $settings['souk_page_boxed_bg_vertical'] : '';
		update_post_meta( $post_id, 'souk_page_boxed_bg_vertical', $page_boxed_bg_vertical );

		$page_boxed_bg_repeat = isset( $settings['souk_page_boxed_bg_repeat'] ) ? $settings['souk_page_boxed_bg_repeat'] : '';
		update_post_meta( $post_id, 'souk_page_boxed_bg_repeat', $page_boxed_bg_repeat );

		$page_boxed_bg_attachment = isset( $settings['souk_page_boxed_bg_attachment'] ) ? $settings['souk_page_boxed_bg_attachment'] : '';
		update_post_meta( $post_id, 'souk_page_boxed_bg_attachment', $page_boxed_bg_attachment );

		$page_boxed_bg_size = isset( $settings['souk_page_boxed_bg_size'] ) ? $settings['souk_page_boxed_bg_size'] : '';
		update_post_meta( $post_id, 'souk_page_boxed_bg_size', $page_boxed_bg_size );

		// Footer
		$footer_section = isset( $settings['souk_hide_footer_section'] ) ? $settings['souk_hide_footer_section'] : '0';
		update_post_meta( $post_id, 'souk_hide_footer_section', $footer_section );

		$footer_border_top = isset( $settings['souk_footer_section_border_top'] ) ? $settings['souk_footer_section_border_top'] : 'default';
		update_post_meta( $post_id, 'souk_footer_section_border_top', $footer_border_top );

		$border_color = isset( $settings['souk_footer_section_border_color'] ) ? $settings['souk_footer_section_border_color'] : 'default';
		update_post_meta( $post_id, 'souk_footer_section_border_color', $border_color );

		$custom_border_color = isset( $settings['souk_footer_section_custom_border_color'] ) ? $settings['souk_footer_section_custom_border_color'] : '';
		update_post_meta( $post_id, 'souk_footer_section_custom_border_color', $custom_border_color );

		// Mobile Version
		$navigation_bar_mobile = isset( $settings['souk_hide_navigation_bar_mobile'] ) ? $settings['souk_hide_navigation_bar_mobile'] : '0';
		update_post_meta( $post_id, 'souk_hide_navigation_bar_mobile', $navigation_bar_mobile );
	}

	/**
	 * Save Elementor page settings when save metabox
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function save_elementor_settings( $post_id, $post, $update ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( isset( $_POST['_elementor_edit_mode_nonce'] ) ) {
			return;
		}

		if ( ! is_admin() ) {
			return;
		}

		if ( $post->post_type !== 'page' ) {
			return;
		}

		// Check permissions
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}


		if ( ! class_exists( '\Elementor\Core\Settings\Manager' ) ) {
			return;
		}

		if ( isset( $_POST['action'] ) && $_POST['action'] == 'elementor_ajax' ) {
			return;
		}

		$settings = array();

		// Header
		if ( isset( $_POST['souk_hide_header_section'] ) ) {
			$settings['souk_hide_header_section'] = $_POST['souk_hide_header_section'];
		}

		if ( isset( $_POST['souk_hide_campain_bar'] ) ) {
			$settings['souk_hide_campain_bar'] = $_POST['souk_hide_campain_bar'];
		}

		if ( isset( $_POST['souk_header_layout'] ) ) {
			$settings['souk_header_layout'] = $_POST['souk_header_layout'];
		}

		if ( isset( $_POST['souk_header_background'] ) ) {
			$settings['souk_header_background'] = $_POST['souk_header_background'];
		}

		if ( isset( $_POST['souk_header_text_color'] ) ) {
			$settings['souk_header_text_color'] = $_POST['souk_header_text_color'];
		}

		if ( isset( $_POST['souk_hide_header_border'] ) ) {
			$settings['souk_hide_header_border'] = $_POST['souk_hide_header_border'];
		}

		if ( isset( $_POST['souk_header_v4_bottom_spacing_bottom'] ) ) {
			$settings['souk_header_v4_bottom_spacing_bottom'] = $_POST['souk_header_v4_bottom_spacing_bottom'];
		}

		if ( isset( $_POST['souk_header_bottom_spacing_bottom'] ) ) {
			$settings['souk_header_bottom_spacing_bottom']['size'] = $_POST['souk_header_bottom_spacing_bottom'];
		}

		if ( isset( $_POST['souk_header_primary_menu'] ) ) {
			$settings['souk_header_primary_menu'] = $_POST['souk_header_primary_menu'];
		}

		if ( isset( $_POST['souk_department_menu_display'] ) ) {
			$settings['souk_department_menu_display'] = $_POST['souk_department_menu_display'];
		}

		if ( isset( $_POST['souk_department_menu_display_spacing'] ) ) {
			$settings['souk_department_menu_display_spacing']['size'] = $_POST['souk_department_menu_display_spacing'];
		}

		// Content
		if ( isset( $_POST['souk_content_width'] ) ) {
			$settings['souk_content_width'] = $_POST['souk_content_width'];
		}
		if ( isset( $_POST['souk_content_top_spacing'] ) ) {
			$settings['souk_content_top_spacing'] = $_POST['souk_content_top_spacing'];
		}
		if ( isset( $_POST['souk_content_top_padding'] ) ) {
			$settings['souk_content_top_padding']['size'] = $_POST['souk_content_top_padding'];
		}
		if ( isset( $_POST['souk_content_bottom_spacing'] ) ) {
			$settings['souk_content_bottom_spacing'] = $_POST['souk_content_bottom_spacing'];
		}
		if ( isset( $_POST['souk_content_bottom_padding'] ) ) {
			$settings['souk_content_bottom_padding']['size'] = $_POST['souk_content_bottom_padding'];
		}

		// Page Header
		if ( isset( $_POST['souk_hide_page_header'] ) ) {
			$settings['souk_hide_page_header'] = $_POST['souk_hide_page_header'];
		}
		if ( isset( $_POST['souk_hide_title'] ) ) {
			$settings['souk_hide_title'] = $_POST['souk_hide_title'];
		}
		if ( isset( $_POST['souk_hide_breadcrumb'] ) ) {
			$settings['souk_hide_breadcrumb'] = $_POST['souk_hide_breadcrumb'];
		}

		if ( isset( $_POST['souk_page_header_layout'] ) ) {
			$settings['souk_page_header_layout'] = $_POST['souk_page_header_layout'];
		}

		if ( isset( $_POST['souk_page_header_image'] ) ) {
			$image_id = $_POST['souk_page_header_image'][0];
			$settings['souk_page_header_image']['id'] = $image_id;
			$bg_image                                 = wp_get_attachment_image_src( $image_id, 'full' );
			if ( $bg_image ) {
				$settings['souk_page_header_image']['url'] = $bg_image[0];
			}
		}
		if ( isset( $_POST['souk_page_header_spacing'] ) ) {
			$settings['souk_page_header_spacing'] = $_POST['souk_page_header_spacing'];
		}
		if ( isset( $_POST['souk_page_header_top_padding'] ) ) {
			$settings['souk_page_header_top_padding']['size'] = $_POST['souk_page_header_top_padding'];
		}
		if ( isset( $_POST['souk_page_header_bottom_padding'] ) ) {
			$settings['souk_page_header_bottom_padding']['size'] = $_POST['souk_page_header_bottom_padding'];
		}

		//Boxed Layout
		if ( isset( $_POST['souk_disable_page_boxed'] ) ) {
			$settings['souk_disable_page_boxed'] = $_POST['souk_disable_page_boxed'];
		}
		if ( isset( $_POST['souk_page_boxed_bg_color'] ) ) {
			$settings['souk_page_boxed_bg_color'] = $_POST['souk_page_boxed_bg_color'];
		}
		if ( isset( $_POST['souk_page_boxed_bg_image'] ) ) {
			$image_id = $_POST['souk_page_boxed_bg_image'][0];
			$settings['souk_page_boxed_bg_image']['id'] = $image_id;
			$bg_image                                 = wp_get_attachment_image_src( $image_id, 'full' );
			if ( $bg_image ) {
				$settings['souk_page_boxed_bg_image']['url'] = $bg_image[0];
			}
		}
		if ( isset( $_POST['souk_page_boxed_bg_horizontal'] ) ) {
			$settings['souk_page_boxed_bg_horizontal'] = $_POST['souk_page_boxed_bg_horizontal'];
		}
		if ( isset( $_POST['souk_page_boxed_bg_vertical'] ) ) {
			$settings['souk_page_boxed_bg_vertical'] = $_POST['souk_page_boxed_bg_vertical'];
		}

		if ( isset( $_POST['souk_page_boxed_bg_repeat'] ) ) {
			$settings['souk_page_boxed_bg_repeat'] = $_POST['souk_page_boxed_bg_repeat'];
		}
		if ( isset( $_POST['souk_page_boxed_bg_attachment'] ) ) {
			$settings['souk_page_boxed_bg_attachment'] = $_POST['souk_page_boxed_bg_attachment'];
		}
		if ( isset( $_POST['souk_page_boxed_bg_size'] ) ) {
			$settings['souk_page_boxed_bg_size'] = $_POST['souk_page_boxed_bg_size'];
		}

		// Footer
		if ( isset( $_POST['souk_hide_footer_section'] ) ) {
			$settings['souk_hide_footer_section'] = $_POST['souk_hide_footer_section'];
		}

		if ( isset( $_POST['souk_footer_section_border_top'] ) ) {
			$settings['souk_footer_section_border_top'] = $_POST['souk_footer_section_border_top'];
		}
		if ( isset( $_POST['souk_footer_section_border_color'] ) ) {
			$settings['souk_footer_section_border_color'] = $_POST['souk_footer_section_border_color'];
		}
		if ( isset( $_POST['souk_footer_section_custom_border_color'] ) ) {
			$settings['souk_footer_section_custom_border_color'] = $_POST['souk_footer_section_custom_border_color'];
		}

		// Mobile Version
		if ( isset( $_POST['souk_hide_navigation_bar_mobile'] ) ) {
			$settings['souk_hide_navigation_bar_mobile'] = $_POST['souk_hide_navigation_bar_mobile'];
		}

		$page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );
		$page_settings_manager->save_settings( $settings, $post_id );

	}

	/**
	 * Get nav menus
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function get_menus() {
		if ( ! is_admin() ) {
			return [];
		}

		$menus = wp_get_nav_menus();
		if ( ! $menus ) {
			return [];
		}

		$output = array(
			0 => esc_html__( 'Default', 'mysouk' ),
		);
		foreach ( $menus as $menu ) {
			$output[ $menu->slug ] = $menu->name;
		}

		return $output;
	}
}
