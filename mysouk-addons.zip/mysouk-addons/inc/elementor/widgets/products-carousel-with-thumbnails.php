<?php

namespace Mysouk\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Group_Control_Image_Size;
use Mysouk\Addons\Elementor\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Products Carousel With Thumbnails widget
 */
class Products_Carousel_With_Thumbnails extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'mysouk-products-carousel-with-thumbnails';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Mysouk - Products Carousel With Thumbnails', 'mysouk' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'mysouk' ];
	}

	public function get_script_depends() {
		$scripts = [
			'mysouk-product-shortcode'
		];

		return $scripts;
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_products_settings_controls();
		$this->section_carousel_settings_controls();
	}

	// Tab Style
	protected function section_style() {
		$this->section_content_style_controls();
		$this->section_carousel_style_controls();
	}

	protected function section_products_settings_controls() {
		$this->start_controls_section(
			'section_products',
			[ 'label' => esc_html__( 'Products', 'mysouk' ) ]
		);

		$this->add_control(
			'source',
			[
				'label'       => esc_html__( 'Source', 'mysouk' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'default' => esc_html__( 'Default', 'mysouk' ),
					'custom'  => esc_html__( 'Custom', 'mysouk' ),
				],
				'default'     => 'default',
				'label_block' => true,
			]
		);

		$this->add_control(
			'limit',
			[
				'label'   => esc_html__( 'Limit', 'mysouk' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 6,
				'min'     => 2,
				'max'     => 38,
				'step'    => 1,
				'condition'   => [
					'source' => 'default',
				],
			]
		);

		$this->add_control(
			'ids',
			[
				'label'       => esc_html__( 'Products', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product',
				'sortable'    => true,
				'condition'   => [
					'source' => 'custom',
				],
			]
		);

		$this->add_control(
			'products',
			[
				'label'     => esc_html__( 'Product', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'recent'       => esc_html__( 'Recent', 'mysouk' ),
					'featured'     => esc_html__( 'Featured', 'mysouk' ),
					'best_selling' => esc_html__( 'Best Selling', 'mysouk' ),
					'top_rated'    => esc_html__( 'Top Rated', 'mysouk' ),
					'sale'         => esc_html__( 'On Sale', 'mysouk' ),
				],
				'default'   => 'recent',
				'toggle'    => false,
				'condition'   => [
					'source' => 'default',
				],
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'     => esc_html__( 'Order By', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''           => esc_html__( 'Default', 'mysouk' ),
					'date'       => esc_html__( 'Date', 'mysouk' ),
					'title'      => esc_html__( 'Title', 'mysouk' ),
					'menu_order' => esc_html__( 'Menu Order', 'mysouk' ),
					'rand'       => esc_html__( 'Random', 'mysouk' ),
				],
				'default'   => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'source',
							'value' => 'default',
						],
						[
							'name' => 'products',
							'operator' => '!=',
							'value' => 'best_selling',
						],
					]
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'     => esc_html__( 'Order', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''     => esc_html__( 'Default', 'mysouk' ),
					'asc'  => esc_html__( 'Ascending', 'mysouk' ),
					'desc' => esc_html__( 'Descending', 'mysouk' ),
				],
				'default'   => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'source',
							'value' => 'default',
						],
						[
							'name' => 'products',
							'operator' => '!=',
							'value' => 'best_selling',
						],
					]
				],
			]
		);

		$this->add_control(
			'product_category',
			[
				'label'       => esc_html__( 'Product Categories', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_cat',
				'sortable'    => true,
				'separator' => 'before',
				'condition'   => [
					'source' => 'default',
				],
			]
		);

		$this->add_control(
			'product_tag',
			[
				'label'       => esc_html__( 'Products Tags', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_tag',
				'sortable'    => true,
				'condition'   => [
					'source' => 'default',
				],
			]
		);

		$this->add_control(
			'product_brands',
			[
				'label'       => esc_html__( 'Products Brands', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_brand',
				'sortable'    => true,
				'condition'   => [
					'source' => 'default',
				],
			]
		);

		if ( taxonomy_exists( 'product_author' ) ) {
			$this->add_control(
				'product_authors',
				[
					'label'       => esc_html__( 'Products Authors', 'mysouk' ),
					'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
					'type'        => 'soukautocomplete',
					'default'     => '',
					'label_block' => true,
					'multiple'    => true,
					'source'      => 'product_author',
					'sortable'    => true,
					'condition'   => [
						'source' => 'default',
					],
				]
			);
		}

		$this->add_control(
			'product_outofstock',
			[
				'label'        => esc_html__( 'Show Out Of Stock Products', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'mysouk' ),
				'label_off'    => esc_html__( 'Hide', 'mysouk' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'   => [
					'source' => 'default',
				],
			]
		);

		$this->add_control(
			'attributes_divider',
			[
				'label' => esc_html__( 'Attributes', 'mysouk' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_quickview',
			[
				'label'     => esc_html__( 'Quick View', 'mysouk' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Hide', 'mysouk' ),
				'label_on'  => __( 'Show', 'mysouk' ),
				'return_value' => 'show',
				'default'   => 'show',
			]
		);

		$this->add_control(
			'show_addtocart',
			[
				'label'     => esc_html__( 'Add To Cart', 'mysouk' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Hide', 'mysouk' ),
				'label_on'  => __( 'Show', 'mysouk' ),
				'return_value' => 'show',
				'default'   => 'show',
			]
		);

		$this->add_control(
			'show_wishlist',
			[
				'label'     => esc_html__( 'Wishlist', 'mysouk' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Hide', 'mysouk' ),
				'label_on'  => __( 'Show', 'mysouk' ),
				'return_value' => 'show',
				'default'   => 'show',
			]
		);

		$this->add_control(
			'show_featured_icons_mobile',
			[
				'label'     => esc_html__( 'Show Featured Icons Mobile', 'mysouk' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Hide', 'mysouk' ),
				'label_on'  => __( 'Show', 'mysouk' ),
				'return_value' => 'show',
				'default'   => 'show',
			]
		);

		$this->end_controls_section();
	}

	protected function section_carousel_settings_controls() {
		$this->start_controls_section(
			'section_carousel_settings',
			[ 'label' => esc_html__( 'Carousel Settings', 'mysouk' ) ]
		);

		$this->add_responsive_control(
			'slidesToShow',
			[
				'label'           => esc_html__( 'Slides to show', 'mysouk' ),
				'type'            => Controls_Manager::NUMBER,
				'min'             => 1,
				'max'             => 7,
				'default' 		=> 3,
				'frontend_available' => true,
			]
		);
		$this->add_responsive_control(
			'slidesToScroll',
			[
				'label'           => esc_html__( 'Slides to scroll', 'mysouk' ),
				'type'            => Controls_Manager::NUMBER,
				'min'             => 1,
				'max'             => 7,
				'default' 		=> 3,
				'frontend_available' => true,
			]
		);
		$this->add_responsive_control(
			'navigation',
			[
				'label'     => esc_html__( 'Navigation', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'none'     => esc_html__( 'None', 'mysouk' ),
					'arrows' => esc_html__( 'Arrows', 'mysouk' ),
					'dots' => esc_html__( 'Dots', 'mysouk' ),
					'dots-arrows' => esc_html__( 'Dots and Arrows', 'mysouk' ),
				],
				'default'   => 'dots',
				'frontend_available' => true,
			]
		);
		$this->add_control(
			'infinite',
			[
				'label'     => __( 'Infinite Loop', 'mysouk' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'mysouk' ),
				'label_on'  => __( 'On', 'mysouk' ),
				'default'   => '',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'     => __( 'Autoplay', 'mysouk' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'mysouk' ),
				'label_on'  => __( 'On', 'mysouk' ),
				'default'   => '',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'speed',
			[
				'label'       => __( 'Speed', 'mysouk' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 800,
				'min'         => 100,
				'step'        => 50,
				'description' => esc_html__( 'Slide animation speed (in ms)', 'mysouk' ),
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
	}

	// Content Settings
	protected function section_content_style_controls() {
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_large_name',
			[
				'label' => esc_html__( 'Image Large', 'mysouk' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'image_large_width',
			[
				'label'      => esc_html__( 'Container Width', 'mysouk' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .products-carousel-with-thumbnails__image-box .product-thumbnail__image' => 'flex: 1 1 {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image_large',
				'default'   => 'full',
			]
		);

		$this->add_control(
			'image_small_name',
			[
				'label' => esc_html__( 'Image Gallery', 'mysouk' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'image_small_width',
			[
				'label'      => esc_html__( 'Container Width', 'mysouk' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .products-carousel-with-thumbnails__image-box .product-thumbnail__gallery' => 'flex: 1 1 {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image_small',
				'default'   => 'full',
			]
		);

		$this->end_controls_section();
	}

	// Carousel Settings
	protected function section_carousel_style_controls() {
		$this->start_controls_section(
			'section_carousel_style',
			[
				'label' => esc_html__( 'Carousel Settings', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'carousel_divider',
			[
				'label' => __( 'Arrows', 'mysouk' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'arrows_font_size',
			[
				'label'     => __( 'Size', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_width',
			[
				'label'     => __( 'Width', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_height',
			[
				'label'     => __( 'Height', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_spacing_horizontal',
			[
				'label'      => __( 'Horizontal Position', 'mysouk' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => - 200,
						'max' => 300,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'sliders_normal_settings' );

		$this->start_controls_tab( 'sliders_normal', [ 'label' => esc_html__( 'Normal', 'mysouk' ) ] );

		$this->add_control(
			'sliders_arrow_color',
			[
				'label'     => esc_html__( 'Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrow_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'sliders_hover', [ 'label' => esc_html__( 'Hover', 'mysouk' ) ] );

		$this->add_control(
			'sliders_arrow_hover_color',
			[
				'label'     => esc_html__( 'Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrow_hover_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .souk-swiper-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'carousel_style_divider_2',
			[
				'label' => __( 'Dots', 'mysouk' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'dots_font_size',
			[
				'label'     => __( 'Size', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .swiper-pagination .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'dots_color',
			[
				'label'     => esc_html__( 'Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .swiper-pagination .swiper-pagination-bullet:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'dots_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'mysouk' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .swiper-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active:before, {{WRAPPER}} .mysouk-products-carousel-with-thumbnails .swiper-pagination .swiper-pagination-bullet:hover:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'dots_spacing_item',
			[
				'label'      => __( 'Item Space', 'mysouk' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .swiper-container-horizontal > .swiper-pagination-bullets .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'dots_spacing',
			[
				'label'      => __( 'Space', 'mysouk' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .mysouk-products-carousel-with-thumbnails .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$nav        = $settings['navigation'];
		$nav_tablet = empty( $settings['navigation_tablet'] ) ? $nav : $settings['navigation_tablet'];
		$nav_mobile = empty( $settings['navigation_mobile'] ) ? $nav : $settings['navigation_mobile'];

		$classes = [
			'mysouk-products-carousel-with-thumbnails mysouk-swiper-carousel-elementor woocommerce mysouk-swiper-slider-elementor',
			'navigation-' . $nav,
			'navigation-tablet-' . $nav_tablet,
			'navigation-mobile-' . $nav_mobile,
			$settings['show_quickview'] != '' ? 'show-quickview' : '',
			$settings['show_addtocart'] != '' ? 'show-addtocart' : '',
			$settings['show_wishlist'] != '' ? 'show-wishlist' : '',
			$settings['show_quickview'] == '' && $settings['show_addtocart'] == '' && $settings['show_wishlist'] == '' ? 'btn-hidden' : ''
		];

		$this->add_render_attribute( 'wrapper', [
			'class' 			=> $classes,
			'data-nonce' 		=> wp_create_nonce( 'mysouk_get_products' )
		] );

		if( $settings['source'] == 'default' ) {
			$attr = [
				'products' 			=> $settings['products'],
				'orderby'  			=> $settings['orderby'],
				'order'    			=> $settings['order'],
				'category'    		=> $settings['product_category'],
				'tag'    			=> $settings['product_tag'],
				'product_brands'    => $settings['product_brands'],
				'limit'    			=> $settings['limit'],
				'paginate'			=> true,
			];

			if ( taxonomy_exists( 'product_author' ) ) {
				$attr['product_authors'] = $settings['product_authors'];
			}

			if ( isset( $settings['product_outofstock'] ) && empty( $settings['product_outofstock'] ) ) {
				$attr['product_outofstock'] = $settings['product_outofstock'];
			}

			$results = Helper::products_shortcode( $attr );
			if ( ! $results ) {
				return;
			}

			$product_ids = $results['ids'];
		} else {
			$product_ids = explode( ",",$settings['ids'] );
		}

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php

			update_meta_cache( 'post', $product_ids );
			update_object_term_cache( $product_ids, 'product' );
			$original_post = $GLOBALS['post'];

			$class_mobile = 'mobile-show-atc';

			if ( $settings['show_featured_icons_mobile'] == 'show' ) {
				$class_mobile .= ' mobile-show-featured-icons';
			}

			if( class_exists('\Mysouk\Helper') && method_exists('\Mysouk\Helper', 'get_option') ) {
				if ( $mobile_pl_col = intval( \Mysouk\Helper::get_option( 'mobile_landscape_product_columns' ) ) ) {
					$class_mobile .= ' mobile-pl-col-' . $mobile_pl_col;
				}

				if ( $mobile_pp_col = intval( \Mysouk\Helper::get_option( 'mobile_portrait_product_columns' ) ) ) {
					$class_mobile .= ' mobile-pp-col-' . $mobile_pp_col;
				}
			}

			echo '<ul class="products product-loop-layout-8 mysouk-products-carousel-with-thumbnails__content '. esc_attr( $class_mobile ) .'">';

			$output = array();
			foreach ( $product_ids as $product_id ) {
				global $product;

				$product = wc_get_product( $product_id );
				$title = get_the_title( $product_id );
				$image_id = get_post_thumbnail_id( $product_id );
				$image_src = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'image_large', [
					'image_large_size' => $settings['image_large_size'],
					'image_large_custom_dimension' => $settings['image_large_custom_dimension'],
				] );

				$gallery_src = '';
				$gallery_html = array();

				if( class_exists('\Mysouk\Helper') && method_exists('\Mysouk\Helper', 'get_option') ) {
					$featured_icons = (array) \Mysouk\Helper::get_option( 'product_loop_featured_icons' );
				}

				if( class_exists('\Mysouk\WooCommerce\Helper') && method_exists('\Mysouk\WooCommerce\Helper', 'quick_view_button') ) {
					ob_start();
					$quickview = in_array( 'qview', $featured_icons ) ? \Mysouk\WooCommerce\Helper::quick_view_button() : '';
					$quickview = ob_get_clean();
				}

				if( class_exists('\Mysouk\WooCommerce\Helper') && method_exists('\Mysouk\WooCommerce\Helper', 'wishlist_button') ) {
					ob_start();
					$wishlist = in_array( 'wlist', $featured_icons ) ? \Mysouk\WooCommerce\Helper::wishlist_button() : '';
					$wishlist = ob_get_clean();
				}

				if( class_exists('\Mysouk\WooCommerce\Helper') && method_exists('\Mysouk\WooCommerce\Helper', 'product_taxonomy') ) {
					ob_start();
					$taxonomy = \Mysouk\WooCommerce\Helper::product_taxonomy();
					$taxonomy = ob_get_clean();
				}

				if( class_exists('\Mysouk\WooCommerce\Helper') && method_exists('\Mysouk\WooCommerce\Helper', 'product_loop_title') ) {
					ob_start();
					$loop_title = \Mysouk\WooCommerce\Helper::product_loop_title();
					$loop_title = ob_get_clean();
				}

				ob_start();
				$price = woocommerce_template_loop_price();
				$price = ob_get_clean();

				ob_start();
				$atc_button = woocommerce_template_loop_add_to_cart();
				$atc_button = ob_get_clean();

				for( $i=0; $i<3; $i++ ) {
					$image_ids = $product->get_gallery_image_ids();

					if( ! empty( $image_ids[$i] ) ) {
						$gallery_src = Group_Control_Image_Size::get_attachment_image_src( $image_ids[$i], 'image_small', [
							'image_small_size' => $settings['image_small_size'],
							'image_small_custom_dimension' => $settings['image_small_custom_dimension'],
						] );

						$gallery_html[] = '<img alt="'. esc_html( $title ) .'" src="'. esc_url( $gallery_src ) .'"/>';
					}
				}

				$output[] = sprintf(
					'<li class="layout-v1 product">
						<div class="product-inner">
							<div class="product-thumbnail">
								<a class="woocommerce-LoopProduct-link woocommerce-loop-product__link products-carousel-with-thumbnails__image-box" href="%s">
									<span class="product-thumbnail__image">
										<img alt="%s" src="%s"/>
									</span>
									<span class="product-thumbnail__gallery">%s</span>
								</a>
								<div class="product-loop-inner__buttons">%s%s</div>
							</div>
							<div class="product-summary">
								<div class="product-loop__top">
									<div class="product-loop__cat-title">
									%s
									<h2 class="woocommerce-loop-product__title">
										<a href="%s" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">%s</a>
									</h2>
									</div>
									%s
								</div>
								<div class="product-loop__buttons">%s%s%s</div>
							</div>
						</div>
					</li>',
					esc_url( get_permalink($product_id) ),
					esc_html( $title ),
					$image_src,
					implode( '', $gallery_html ),
					$quickview,
					$wishlist,
					$taxonomy,
					esc_url( get_permalink( $product_id ) ),
					$title,
					$price,
					$atc_button,
					$quickview,
					$wishlist
				);

			}

			echo implode( '', $output );

			$GLOBALS['post'] = $original_post; // WPCS: override ok.

			echo '</ul>';

			wp_reset_postdata();

			?>
		</div>
		<?php
	}
}