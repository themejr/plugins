<?php

namespace Mysouk\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Group_Control_Box_Shadow;
use Mysouk\Addons\Elementor\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Products_Grid extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'mysouk-products-grid';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Mysouk - Products Grid', 'mysouk' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'mysouk' ];
	}

	public function get_script_depends() {
		return [
			'mysouk-product-shortcode'
		];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_products_settings_controls();
		$this->section_pagination_settings_controls();
	}

	// Tab Style
	protected function section_style() {
		$this->section_content_style_controls();
	}

	protected function section_products_settings_controls() {
		$this->start_controls_section(
			'section_products',
			[ 'label' => esc_html__( 'Products', 'mysouk' ) ]
		);

		$this->add_control(
			'per_page',
			[
				'label'   => esc_html__( 'Total Products', 'mysouk' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
				'min'     => 1,
				'max'     => 200,
				'step'    => 1,
				'frontend_available' => true,
				'condition' => [
					'products'            => [ 'recent', 'top_rated', 'sale', 'featured', 'best_selling' ],
				],
			]
		);

		$this->add_control(
			'columns',
			[
				'label'   => esc_html__( 'Columns', 'mysouk' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 7,
				'step'    => 1,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'products',
			[
				'label'     => esc_html__( 'Product', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'recent'       => esc_html__( 'Recent', 'mysouk' ),
					'featured'     => esc_html__( 'Featured', 'mysouk' ),
					'best_selling' => esc_html__( 'Best Selling', 'mysouk' ),
					'top_rated'    => esc_html__( 'Top Rated', 'mysouk' ),
					'sale'         => esc_html__( 'On Sale', 'mysouk' ),
					'custom'       => esc_html__( 'Custom', 'mysouk' ),
				],
				'default'   => 'recent',
				'toggle'    => false,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'ids',
			[
				'label'       => esc_html__( 'Products', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product',
				'sortable'    => true,
				'condition'   => [
					'products' => 'custom',
				],
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'     => esc_html__( 'Order By', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''           => esc_html__( 'Default', 'mysouk' ),
					'date'       => esc_html__( 'Date', 'mysouk' ),
					'title'      => esc_html__( 'Title', 'mysouk' ),
					'menu_order' => esc_html__( 'Menu Order', 'mysouk' ),
					'rand'       => esc_html__( 'Random', 'mysouk' ),
				],
				'default'   => '',
				'condition' => [
					'products'            => [ 'recent', 'top_rated', 'sale', 'featured' ],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'order',
			[
				'label'     => esc_html__( 'Order', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''     => esc_html__( 'Default', 'mysouk' ),
					'asc'  => esc_html__( 'Ascending', 'mysouk' ),
					'desc' => esc_html__( 'Descending', 'mysouk' ),
				],
				'default'   => '',
				'condition' => [
					'products'            => [ 'recent', 'top_rated', 'sale', 'featured' ],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'category',
			[
				'label'       => esc_html__( 'Products Category', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_cat',
				'sortable'    => true,
				'separator' => 'before',
				'condition' => [
					'products'            => [ 'recent', 'top_rated', 'sale', 'featured' ],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'product_tags',
			[
				'label'       => esc_html__( 'Products Tags', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_tag',
				'sortable'    => true,
				'condition' => [
					'products'            => [ 'recent', 'top_rated', 'sale', 'featured' ],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'product_brands',
			[
				'label'       => esc_html__( 'Products Brands', 'mysouk' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
				'type'        => 'soukautocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_brand',
				'sortable'    => true,
				'condition' => [
					'products'            => [ 'recent', 'top_rated', 'sale', 'featured' ],
				],
				'frontend_available' => true,
			]
		);

		if ( taxonomy_exists( 'product_author' ) ) {
			$this->add_control(
				'product_authors',
				[
					'label'       => esc_html__( 'Products Authors', 'mysouk' ),
					'placeholder' => esc_html__( 'Click here and start typing...', 'mysouk' ),
					'type'        => 'soukautocomplete',
					'default'     => '',
					'label_block' => true,
					'multiple'    => true,
					'source'      => 'product_author',
					'sortable'    => true,
					'condition' => [
						'products'            => [ 'recent', 'top_rated', 'sale', 'featured' ],
					],
					'frontend_available' => true,
				]
			);
		}

		$this->add_control(
			'product_outofstock',
			[
				'label'        => esc_html__( 'Show Out Of Stock Products', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'mysouk' ),
				'label_off'    => esc_html__( 'Hide', 'mysouk' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'conditions' => [
					'terms' => [
						[
							'name' => 'products',
							'operator' => '!=',
							'value' => 'custom',
						],
					],
				],
			]
		);

		$this->end_controls_section();
	}

	protected function section_pagination_settings_controls() {
		// Pagination Settings
		$this->start_controls_section(
			'section_pagination',
			[
				'label' => esc_html__( 'Pagination', 'mysouk' ),
			]
		);

		$this->add_control(
			'pagination_enable',
			[
				'label'        => esc_html__( 'Pagination', 'mysouk' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'mysouk' ),
				'label_off'    => esc_html__( 'Hide', 'mysouk' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);
		$this->add_control(
			'pagination_type',
			[
				'label'     => esc_html__( 'Pagination Type', 'mysouk' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'numeric'  => esc_html__( 'Numeric', 'mysouk' ),
					'loadmore' => esc_html__( 'Load More', 'mysouk' ),
					'infinite' => esc_html__( 'Infinite Scroll', 'mysouk' ),
				],
				'default'   => 'loadmore',
				'toggle'    => false,
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'   => esc_html__( 'Button text', 'mysouk' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Load More', 'mysouk' ),
				'conditions' => [
					'terms' => [
						[
							'name'  	=> 'pagination_type',
							'operator' 	=> '!=',
							'value' 	=> 'numeric',
						],
					],
				]
			]
		);

		$this->end_controls_section(); // End Pagination Settings
	}

	protected function section_content_style_controls() {
		// Content Tab Style
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'mysouk' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'   => esc_html__( 'Alignment', 'mysouk' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'left',
				'options' => [
					'left'   => [
						'title' => esc_html__( 'Left', 'mysouk' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'mysouk' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'mysouk' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-grid ul.products li.product .product-inner' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => __( 'Box Shadow', 'mysouk' ),
				'selector' => '{{WRAPPER}} .mysouk-products-grid ul li.product .product-inner:not(:hover)',
			]
		);

		$this->add_responsive_control(
			'button_spacing',
			[
				'label'     => esc_html__( 'Pagination Spacing', 'mysouk' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 150,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .mysouk-products-grid .woocommerce-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .mysouk-products-grid .mysouk-load-more' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'button_type',
			[
				'label'   => esc_html__( 'Button Type', 'mysouk' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'button-smaller' => esc_html__( 'Smaller', 'mysouk' ),
					'button-medium' => esc_html__( 'Medium', 'mysouk' ),
					'button-larger'  => esc_html__( 'Larger', 'mysouk' ),
					'button-big'  => esc_html__( 'Big', 'mysouk' ),
					'button-outline'  => esc_html__( 'Outline', 'mysouk' ),
				],
				'default' => 'button-larger',
				'toggle'  => false,
				'conditions' => [
					'terms' => [
						[
							'name'  	=> 'pagination_type',
							'operator' 	=> '!=',
							'value' 	=> 'numeric',
						],
					],
				]
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'mysouk-products-grid woocommerce'
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		$attr = [
			'products' 			=> $settings['products'],
			'orderby'  			=> $settings['orderby'],
			'order'    			=> $settings['order'],
			'category'    		=> $settings['category'],
			'tag'    			=> $settings['product_tags'],
			'product_brands'    => $settings['product_brands'],
			'limit'    			=> $settings['per_page'],
			'columns'    		=> $settings['columns'],
			'product_ids'   	=> explode(',', $settings['ids']),
			'paginate'			=> true,
		];

		if ( taxonomy_exists( 'product_author' ) ) {
			$attr['product_authors'] = $settings['product_authors'];
		}

		if ( isset( $settings['product_outofstock'] ) && empty( $settings['product_outofstock'] ) ) {
			$attr['product_outofstock'] = $settings['product_outofstock'];
		}

		$results = Helper::products_shortcode( $attr );
		if ( ! $results ) {
			return;
		}

		$results_ids = ! empty($results['ids']) ? $results['ids'] : 0;

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php
				echo '<div class="product-content">';

				wc_setup_loop(
					array(
						'columns'      => $settings['columns']
					)
				);

			Helper::get_template_loop( $results_ids );

				echo '</div>';

				if ( $settings['pagination_enable'] == 'yes' ) {
					if ( $settings['pagination_type'] == 'numeric') {
						self::get_pagination( $results['total_pages'], $results['current_page'] );
					} if ( $settings['pagination_type'] == 'loadmore' || $settings['pagination_type'] == 'infinite' ) {
						if ( $results['current_page'] < $results['total_pages']  ) {
							echo sprintf(
								'<a href="#" class="ajax-load-products mysouk-button %s %s" data-page="%s" rel="nofollow">
									<span class="button-text">%s</span>
									<span class="dots mysouk-gooey">
										<span></span>
										<span></span>
										<span></span>
									</span>
								</a>',
								$settings['button_type'],
								$settings['pagination_type'] == 'infinite' ? 'ajax-infinite' : '',
								esc_attr( $results['current_page'] + 1 ),
								$settings['button_text']
							);
						}
					}
				}
			?>
		</div>
		<?php
	}

	/**
	 * Products pagination.
	 */
	public static function get_pagination( $total_pages, $current_page ) {
		echo '<nav class="woocommerce-pagination">';
		echo paginate_links(
			array( // WPCS: XSS ok.
				'base'      => esc_url_raw( add_query_arg( 'product-page', '%#%', false ) ),
				'format'    => '?product-page=%#%',
				'add_args'  => false,
				'current'   => max( 1, $current_page ),
				'total'     => $total_pages,
				'prev_text' => \Mysouk\Addons\Helper::get_svg( 'caret-right' ),
				'next_text' => \Mysouk\Addons\Helper::get_svg( 'caret-right' ),
				'type'      => 'list',
			)
		);
		echo '</nav>';
	}
}