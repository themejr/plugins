<?php
/**
 * Elementor init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Mysouk
 */

namespace Mysouk\Addons;

/**
 * Integrate with Elementor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Elementor {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->add_actions();
	}

	/**
	 * Includes files which are not widgets
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Mysouk\Addons\Auto_Loader::register( [
			'Mysouk\Addons\Elementor\Helper'                 => MYSOUK_ADDONS_DIR . 'inc/elementor/class-elementor-helper.php',
			'Mysouk\Addons\Elementor\Setup'                  => MYSOUK_ADDONS_DIR . 'inc/elementor/class-elementor-setup.php',
			'Mysouk\Addons\Elementor\AjaxLoader'             => MYSOUK_ADDONS_DIR . 'inc/elementor/class-elementor-ajaxloader.php',
			'Mysouk\Addons\Elementor\Widgets'                => MYSOUK_ADDONS_DIR . 'inc/elementor/class-elementor-widgets.php',
			'Mysouk\Addons\Elementor\Module\Column_Settings' => MYSOUK_ADDONS_DIR . 'inc/elementor/modules/column-settings.php',
			'Mysouk\Addons\Elementor\Module\Motion_Parallax' => MYSOUK_ADDONS_DIR . 'inc/elementor/modules/class-elementor-motion-parallax.php',
			'Mysouk\Addons\Elementor\Controls'               => MYSOUK_ADDONS_DIR . 'inc/elementor/controls/class-elementor-controls.php',
			'Mysouk\Addons\Elementor\Page_Settings'          => MYSOUK_ADDONS_DIR . 'inc/elementor/class-elementor-page-settings.php',
		] );

	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		$this->get( 'setup' );
		$this->get( 'ajax_loader' );
		$this->get( 'widgets' );
		$this->get( 'controls' );
		$this->get( 'page_settings' );
		$this->get( 'column_settings' );

		if ( ! defined( 'ELEMENTOR_PRO_VERSION' ) ) {
			$this->modules['motion_parallax'] = $this->get( 'motion_parallax' );
		}
	}

	/**
	 * Get Mysouk Elementor Class instance
	 *
	 * @since 1.0.0
	 *
	 * @return object
	 */
	public function get( $class ) {
		switch ( $class ) {
			case 'setup':
				return \Mysouk\Addons\Elementor\Setup::instance();
				break;
			case 'ajax_loader':
				return \Mysouk\Addons\Elementor\AjaxLoader::instance();
				break;
			case 'widgets':
				return \Mysouk\Addons\Elementor\Widgets::instance();
				break;
			case 'column_settings':
				return \Mysouk\Addons\Elementor\Module\Column_Settings::instance();
				break;
			case 'motion_parallax':
				if ( ! defined( 'ELEMENTOR_PRO_VERSION' ) ) {
					return \Mysouk\Addons\Elementor\Module\Motion_Parallax::instance();
				}
				break;
			case 'controls':
				return \Mysouk\Addons\Elementor\Controls::instance();
				break;
			case 'page_settings':
				return \Mysouk\Addons\Elementor\Page_Settings::instance();
				break;
		}
	}
}
