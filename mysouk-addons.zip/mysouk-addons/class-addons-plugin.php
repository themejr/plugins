<?php
/**
 * Mysouk Addons init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Mysouk
 */

namespace Mysouk;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Mysouk Addons init
 *
 * @since 1.0.0
 */
class Addons {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_templates' ) );
	}

	/**
	 * Load Templates
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function load_templates() {
		$this->includes();
		spl_autoload_register( '\Mysouk\Addons\Auto_Loader::load' );

		$this->add_actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		// Auto Loader
		require_once MYSOUK_ADDONS_DIR . 'class-addons-autoloader.php';
		\Mysouk\Addons\Auto_Loader::register( [
			'Mysouk\Addons\Helper'         => MYSOUK_ADDONS_DIR . 'class-addons-helper.php',
			'Mysouk\Addons\Widgets'        => MYSOUK_ADDONS_DIR . 'inc/widgets/class-addons-widgets.php',
			'Mysouk\Addons\Modules'        => MYSOUK_ADDONS_DIR . 'modules/modules.php',
			'Mysouk\Addons\Elementor'      => MYSOUK_ADDONS_DIR . 'inc/elementor/class-elementor.php',
			'Mysouk\Addons\Product_Brands' => MYSOUK_ADDONS_DIR . 'inc/backend/class-addons-product-brand.php',
			'Mysouk\Addons\Product_Authors'=> MYSOUK_ADDONS_DIR . 'inc/backend/class-addons-product-author.php',
			'Mysouk\Addons\Importer'       => MYSOUK_ADDONS_DIR . 'inc/backend/importer.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		// Before init action.
		do_action( 'before_mysouk_init' );

		$this->get( 'product_brand' );
		$this->get( 'product_author' );

		$this->get( 'importer' );

		// Elmentor
		$this->get( 'elementor' );

		// Modules
		$this->get( 'modules' );

		// Widgets
		$this->get( 'widgets' );

		add_action( 'after_setup_theme', array( $this, 'addons_init' ), 20 );

		// Init action.
		do_action( 'after_mysouk_init' );
	}

	/**
	 * Get Mysouk Addons Class instance
	 *
	 * @since 1.0.0
	 *
	 * @return object
	 */
	public function get( $class ) {
		switch ( $class ) {
			case 'product_brand':
				if ( class_exists( 'WooCommerce' ) ) {
					return \Mysouk\Addons\Product_Brands::instance();
				}
				break;
			case 'product_author':
				if ( class_exists( 'WooCommerce' ) ) {
					return \Mysouk\Addons\Product_Authors::instance();
				}
				break;
			case 'importer':
				if ( is_admin() ) {
					return \Mysouk\Addons\Importer::instance();
				}
				break;
			case 'elementor':
				if ( did_action( 'elementor/loaded' ) ) {
					return \Mysouk\Addons\Elementor::instance();
				}
				break;

			case 'modules':
				return \Mysouk\Addons\Modules::instance();
				break;

			case 'widgets':
				return \Mysouk\Addons\Widgets::instance();
				break;
		}
	}

	/**
	 * Get Mysouk Addons Language
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function addons_init() {
		load_plugin_textdomain( 'mysouk', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );
	}
}
