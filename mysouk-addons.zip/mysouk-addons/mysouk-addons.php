<?php
/**
 * Plugin Name: Mysouk Addons
 * Plugin URI: https://themejr.com/mysouk
 * Description: Extra elements for Elementor. It was built for Mysouk theme.
 * Version: 1.0.0
 * Author: ThemeJR
 * Author URI: https://themejr.com/
 * License: GPL2+
 * Text Domain: mysouk
 * Domain Path: /lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'MYSOUK_ADDONS_DIR' ) ) {
	define( 'MYSOUK_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'MYSOUK_ADDONS_URL' ) ) {
	define( 'MYSOUK_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once MYSOUK_ADDONS_DIR . 'class-addons-plugin.php';

\Mysouk\Addons::instance();