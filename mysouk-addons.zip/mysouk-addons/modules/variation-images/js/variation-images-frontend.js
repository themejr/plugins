(function ($) {
    'use strict';
    var mysouk = mysouk || {};

    mysouk.found_data = false;
    mysouk.variation_id = 0;

    mysouk.foundVariationImages = function( ) {
        $( '.variations_form:not(.form-cart-pbt)' ).on('found_variation', function(e, $variation){
            if( mysouk.variation_id != $variation.variation_id ) {
                mysouk.changeVariationImagesAjax($variation.variation_id, $(this).data('product_id'));
                mysouk.found_data = true;
                mysouk.variation_id = $variation.variation_id;
            }
        });
    }

    mysouk.resetVariationImages = function( ) {
        $( '.variations_form:not(.form-cart-pbt)' ).on('reset_data', function(e){
            if( mysouk.found_data ) {
                mysouk.changeVariationImagesAjax(0, $(this).data('product_id'));
                mysouk.found_data = false;
                mysouk.variation_id = 0;
            }

        });
    }

    mysouk.changeVariationImagesAjax = function(variation_id, product_id) {
        var $productGallery = $('.woocommerce-product-gallery'),
            galleryHeight = $productGallery.height();
            $productGallery.addClass('loading').css( {'overflow': 'hidden' });
            if( ! $productGallery.closest('.single-product').hasClass('quick-view-modal') ) {
                $productGallery.css( {'height': galleryHeight });
            }
        var data = {
            'variation_id': variation_id,
            'product_id': product_id,
            nonce: mysoukData.nonce,
        },
        ajax_url = mysoukData.ajax_url.toString().replace('%%endpoint%%', 'mysouk_get_variation_images');

        var xhr = $.post(
            ajax_url,
            data,
            function (response) {
                var $gallery = $(response.data);

                $productGallery.html( $gallery.html() );
                if ( typeof wc_single_product_params !== 'undefined' && $.fn.wc_product_gallery) {
                    $productGallery.removeData('flexslider');
                    $productGallery.off('click', '.woocommerce-product-gallery__image a');
                    $productGallery.off('click', '.woocommerce-product-gallery__trigger');
                    $productGallery.wc_product_gallery( wc_single_product_params );
                    $productGallery.trigger('product_thumbnails_slider_horizontal');
                    $productGallery.trigger('product_thumbnails_slider_vertical');
                }
                $productGallery.trigger('mysouk_update_product_gallery_on_quickview');
                $productGallery.trigger('product-images-slider');

                $productGallery.imagesLoaded(function () {
                    setTimeout(function() {
                        $productGallery.removeClass('loading').removeAttr( 'style' ).css('opacity', '1');
                    }, 200);
                    $productGallery.trigger( 'mysouk_gallery_init_zoom', $productGallery.find('.woocommerce-product-gallery__image').first());
                } );

            }
        );
    }
    /**
     * Document ready
     */
    $(function () {
        if( $('div.product' ).hasClass('product-has-variation-images') ) {
            mysouk.foundVariationImages();
            mysouk.resetVariationImages();
        }

        $('body').on( 'mysouk_product_quick_view_loaded', function() {
            if( $('div.product' ).hasClass('product-has-variation-images') ) {
                mysouk.foundVariationImages();
                mysouk.resetVariationImages();
            }
        } );
    });

})(jQuery);