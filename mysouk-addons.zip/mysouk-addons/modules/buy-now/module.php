<?php
/**
 * Mysouk Addons Modules functions and definitions.
 *
 * @package Mysouk
 */

namespace Mysouk\Addons\Modules\Buy_Now;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Module {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->add_actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Mysouk\Addons\Auto_Loader::register( [
			'Mysouk\Addons\Modules\Buy_Now\Frontend'        => MYSOUK_ADDONS_DIR . 'modules/buy-now/frontend.php',
			'Mysouk\Addons\Modules\Buy_Now\Settings'    	=> MYSOUK_ADDONS_DIR . 'modules/buy-now/settings.php',
		] );
	}


	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		if ( is_admin() ) {
			\Mysouk\Addons\Modules\Buy_Now\Settings::instance();
		}

		if ( get_option( 'souk_buy_now' ) == 'yes' ) {
			\Mysouk\Addons\Modules\Buy_Now\Frontend::instance();
		}
	}

}
