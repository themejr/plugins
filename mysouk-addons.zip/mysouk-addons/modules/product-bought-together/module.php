<?php
/**
 * Mysouk Addons Modules functions and definitions.
 *
 * @package Mysouk
 */

namespace Mysouk\Addons\Modules\Product_Bought_Together;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Module {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Mysouk\Addons\Auto_Loader::register( [
			'Mysouk\Addons\Modules\Product_Bought_Together\Frontend'        => MYSOUK_ADDONS_DIR . 'modules/product-bought-together/frontend.php',
			'Mysouk\Addons\Modules\Product_Bought_Together\Settings'    	=> MYSOUK_ADDONS_DIR . 'modules/product-bought-together/settings.php',
			'Mysouk\Addons\Modules\Product_Bought_Together\Product_Meta'    => MYSOUK_ADDONS_DIR . 'modules/product-bought-together/product-meta.php',
		] );
	}


	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		if ( is_admin() ) {
			\Mysouk\Addons\Modules\Product_Bought_Together\Settings::instance();
		}

		if ( get_option( 'souk_product_bought_together' ) == 'yes' ) {
			\Mysouk\Addons\Modules\Product_Bought_Together\Frontend::instance();

			if ( is_admin() ) {
				\Mysouk\Addons\Modules\Product_Bought_Together\Product_Meta::instance();
			}
		}

	}

}
