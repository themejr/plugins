jQuery( document ).ready( function( $ ) {
	$( '.mysouk-size-guide-tabs' ).on( 'click', '.mysouk-size-guide-tabs__nav li', function() {
        var $tab = $( this ),
            index = $tab.data( 'target' ),
            $panels = $tab.closest( '.mysouk-size-guide-tabs' ).find( '.mysouk-size-guide-tabs__panels' ),
            $panel = $panels.find( '.mysouk-size-guide-tabs__panel[data-panel="' + index + '"]' );

        if ( $tab.hasClass( 'active' ) ) {
            return;
        }

        $tab.addClass( 'active' ).siblings( 'li.active' ).removeClass( 'active' );

        if ( $panel.length ) {
            $panel.addClass( 'active' ).siblings( '.mysouk-size-guide-tabs__panel.active' ).removeClass( 'active' );
        }
    } );
} );