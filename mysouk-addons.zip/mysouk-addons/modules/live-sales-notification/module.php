<?php
/**
 * Mysouk Addons Modules functions and definitions.
 *
 * @package Mysouk
 */

namespace Mysouk\Addons\Modules\Live_Sales_Notification;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Module {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Mysouk\Addons\Auto_Loader::register( [
			'Mysouk\Addons\Modules\Live_Sales_Notification\Settings'   => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/settings.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Frontend'   => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/frontend.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Helper'     => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/helper.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Navigation' => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/navigation/navigation.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		if ( is_admin() ) {
			\Mysouk\Addons\Modules\Live_Sales_Notification\Settings::instance();
		}

		if ( get_option( 'mysouk_live_sales_notification' ) == 'yes' ) {
			\Mysouk\Addons\Modules\Live_Sales_Notification\Helper::instance();
			\Mysouk\Addons\Modules\Live_Sales_Notification\Frontend::instance();
			\Mysouk\Addons\Modules\Live_Sales_Notification\Navigation::instance();
		}
	}

}
