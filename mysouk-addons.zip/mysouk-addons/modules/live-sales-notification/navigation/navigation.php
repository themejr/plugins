<?php
/**
 * Mysouk Addons Modules functions and definitions.
 *
 * @package Mysouk
 */

namespace Mysouk\Addons\Modules\Live_Sales_Notification;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Navigation
 */
class Navigation {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Mysouk\Addons\Auto_Loader::register( [
			'Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Orders_Fake'       => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/navigation/orders-fake.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Orders'    	       => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/navigation/orders.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Product_Type' 	   => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/navigation/product-type.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Selected_Products' => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/navigation/selected-products.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Categories'		   => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/navigation/categories.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		\Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Orders_Fake::instance();
		\Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Orders::instance();
		\Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Product_Type::instance();
		\Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Selected_Products::instance();
		\Mysouk\Addons\Modules\Live_Sales_Notification\Navigation\Categories::instance();
	}

}
