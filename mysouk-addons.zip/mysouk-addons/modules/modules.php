<?php
/**
 * Mysouk Addons Modules functions and definitions.
 *
 * @package Mysouk
 */

namespace Mysouk\Addons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Modules {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->add_actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Mysouk\Addons\Auto_Loader::register( [
			'Mysouk\Addons\Modules\Size_Guide\Module'    			=> MYSOUK_ADDONS_DIR . 'modules/size-guide/module.php',
			'Mysouk\Addons\Modules\Catalog_Mode\Module'    			=> MYSOUK_ADDONS_DIR . 'modules/catalog-mode/module.php',
			'Mysouk\Addons\Modules\Product_Deals\Module'    			=> MYSOUK_ADDONS_DIR . 'modules/product-deals/module.php',
			'Mysouk\Addons\Modules\Buy_Now\Module'    				=> MYSOUK_ADDONS_DIR . 'modules/buy-now/module.php',
			'Mysouk\Addons\Modules\Mega_Menu\Module'    				=> MYSOUK_ADDONS_DIR . 'modules/mega-menu/module.php',
			'Mysouk\Addons\Modules\Products_Filter\Module'     		=> MYSOUK_ADDONS_DIR . 'modules/products-filter/module.php',
			'Mysouk\Addons\Modules\Related_Products\Module'    		=> MYSOUK_ADDONS_DIR . 'modules/related-products/module.php',
			'Mysouk\Addons\Modules\Product_Tabs\Module'    			=> MYSOUK_ADDONS_DIR . 'modules/product-tabs/module.php',
			'Mysouk\Addons\Modules\Variation_Images\Module'    		=> MYSOUK_ADDONS_DIR . 'modules/variation-images/module.php',
			'Mysouk\Addons\Modules\Product_Bought_Together\Module'   => MYSOUK_ADDONS_DIR . 'modules/product-bought-together/module.php',
			'Mysouk\Addons\Modules\Free_Shipping_Bar\Module'    		=> MYSOUK_ADDONS_DIR . 'modules/free-shipping-bar/module.php',
			'Mysouk\Addons\Modules\Live_Sales_Notification\Module'   => MYSOUK_ADDONS_DIR . 'modules/live-sales-notification/module.php',
			'Mysouk\Addons\Modules\Ajax'    							=> MYSOUK_ADDONS_DIR . 'modules/ajax.php',
			'Mysouk\Addons\Modules\Shortcodes' 						=> MYSOUK_ADDONS_DIR . 'modules/shortcodes.php',
		] );

	}


	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		if ( is_admin() ) {
			\Mysouk\Addons\Modules\Ajax::instance();
		}

		if ( class_exists( 'WooCommerce' ) ) {
			\Mysouk\Addons\Modules\Buy_Now\Module::instance();
			\Mysouk\Addons\Modules\Catalog_Mode\Module::instance();
			\Mysouk\Addons\Modules\Product_Deals\Module::instance();
			\Mysouk\Addons\Modules\Products_Filter\Module::instance();
			\Mysouk\Addons\Modules\Size_Guide\Module::instance();
			\Mysouk\Addons\Modules\Related_Products\Module::instance();
			\Mysouk\Addons\Modules\Product_Tabs\Module::instance();
			\Mysouk\Addons\Modules\Variation_Images\Module::instance();
			\Mysouk\Addons\Modules\Free_Shipping_Bar\Module::instance();
			\Mysouk\Addons\Modules\Product_Bought_Together\Module::instance();
			\Mysouk\Addons\Modules\Live_Sales_Notification\Module::instance();
		}

		\Mysouk\Addons\Modules\Mega_Menu\Module::instance();
		\Mysouk\Addons\Modules\Shortcodes::instance();
	}

}
