<# if ( data.depth == 0 ) { #>
<a href="#" class="media-menu-item active" data-title="<?php esc_attr_e( 'Mega Menu Content', 'mysouk' ) ?>"
   data-panel="mega"><?php esc_html_e( 'Mega Menu', 'mysouk' ) ?></a>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Mega Menu Background', 'mysouk' ) ?>"
   data-panel="background"><?php esc_html_e( 'Background', 'mysouk' ) ?></a>
<div class="separator"></div>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Menu Badges', 'mysouk' ) ?>"
   data-panel="badges"><?php esc_html_e( 'Badges', 'mysouk' ) ?></a>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Menu Icon', 'mysouk' ) ?>"
   data-panel="icon"><?php esc_html_e( 'Icon', 'mysouk' ) ?></a>
<# } else if ( data.depth == 1 ) { #>
<a href="#" class="media-menu-item active" data-title="<?php esc_attr_e( 'Menu Content', 'mysouk' ) ?>"
   data-panel="content"><?php esc_html_e( 'Menu Content', 'mysouk' ) ?></a>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Menu General', 'mysouk' ) ?>"
   data-panel="general"><?php esc_html_e( 'General', 'mysouk' ) ?></a>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Menu Badges', 'mysouk' ) ?>"
   data-panel="badges"><?php esc_html_e( 'Badges', 'mysouk' ) ?></a>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Menu Icon', 'mysouk' ) ?>"
   data-panel="icon"><?php esc_html_e( 'Icon', 'mysouk' ) ?></a>
<# } else { #>
<a href="#" class="media-menu-item active" data-title="<?php esc_attr_e( 'Menu General', 'mysouk' ) ?>"
   data-panel="general_2"><?php esc_html_e( 'General', 'mysouk' ) ?></a>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Menu Badges', 'mysouk' ) ?>"
   data-panel="badges"><?php esc_html_e( 'Badges', 'mysouk' ) ?></a>
<a href="#" class="media-menu-item" data-title="<?php esc_attr_e( 'Menu Icon', 'mysouk' ) ?>"
   data-panel="icon"><?php esc_html_e( 'Icon', 'mysouk' ) ?></a>
<# } #>
