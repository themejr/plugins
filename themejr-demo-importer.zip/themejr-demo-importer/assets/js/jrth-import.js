jQuery(document).ready(function ($) {
    "use strict";

    var themejr = {
        init: function () {
            this.$progress = $('#jrth-demo-import-progress');
            this.$log = $('#jrth-demo-import-log');
            this.$importer = $('#jrth-demo-importer');
            this.steps = ['content', 'customizer', 'widgets', 'sliders'];

            this.tabs();

            if (!this.$importer.length) {
                return;
            }

            /**
             * The first step: download content file
             */
            this.download(themejr.steps.shift());
        },

        tabs: function () {
            var $tabs = $('.techtec-tabs'),
                $el = $tabs.find('.tabs-nav a'),
                $panels = $tabs.find('.tabs-panel');

            $el.on('click', function (e) {
                e.preventDefault();

                var $tab = $(this),
                    index = $tab.parent().index();

                if ($tab.hasClass('active')) {
                    return;
                }

                $tabs.find('.tabs-nav a').removeClass('active');
                $tab.addClass('active');
                $panels.removeClass('active');
                $panels.filter(':eq(' + index + ')').addClass('active');
            });
        },
        download: function (type) {
            themejr.log('Downloading ' + type + ' file');

            $.get(
                ajaxurl,
                {
                    action: 'themejr_download_file',
                    type: type,
                    demo: themejr.$importer.find('input[name="demo"]').val(),
                    _wpnonce: themejr.$importer.find('input[name="_wpnonce"]').val()
                },
                function (response) {
                    if (response.success) {
                        themejr.import(type);
                    } else {
                        themejr.log(response.data);

                        if (themejr.steps.length) {
                            themejr.download(themejr.steps.shift());
                        } else {
                            themejr.configTheme();
                        }
                    }
                }
            ).fail(function () {
                themejr.log('Failed');
            });
        },

        import: function (type) {
            themejr.log('Importing ' + type);

            var data = {
                action: 'themejr_import',
                type: type,
                _wpnonce: themejr.$importer.find('input[name="_wpnonce"]').val()
            };
            var url = ajaxurl + '?' + $.param(data);
            var evtSource = new EventSource(url);

            evtSource.addEventListener('message', function (message) {
                var data = JSON.parse(message.data);

                switch (data.action) {
                    case 'updateTotal':
                        console.log(data.delta);
                        break;

                    case 'updateDelta':
                        console.log(data.delta);
                        break;

                    case 'complete':
                        evtSource.close();
                        themejr.log(type + ' has been imported successfully!');

                        if (themejr.steps.length) {
                            themejr.download(themejr.steps.shift());
                        } else {
                            themejr.configTheme();
                        }

                        break;
                }
            });

            evtSource.addEventListener('log', function (message) {
                var data = JSON.parse(message.data);
                themejr.log(data.message);
            });
        },

        configTheme: function () {
            $.get(
                ajaxurl,
                {
                    action: 'themejr_config_theme',
                    demo: themejr.$importer.find('input[name="demo"]').val(),
                    _wpnonce: themejr.$importer.find('input[name="_wpnonce"]').val()
                },
                function (response) {
                    if (response.success) {
                        themejr.generateImages();
                    }

                    themejr.log(response.data);
                }
            ).fail(function () {
                themejr.log('Failed');
            });
        },

        generateImages: function () {
            $.get(
                ajaxurl,
                {
                    action: 'themejr_get_images',
                    _wpnonce: themejr.$importer.find('input[name="_wpnonce"]').val()
                },
                function (response) {
                    if (!response.success) {
                        themejr.log(response.data);
                        themejr.log('Import completed!');
                        themejr.$progress.find('.spinner').hide();
                        return;
                    } else {
                        var ids = response.data;

                        if (!ids.length) {
                            themejr.log('Import completed!');
                            themejr.$progress.find('.spinner').hide();
                        }

                        themejr.log('Starting generate ' + ids.length + ' images');

                        themejr.generateSingleImage(ids);
                    }
                }
            );
        },

        generateSingleImage: function (ids) {
            if (!ids.length) {
                themejr.log('Import completed!');
                themejr.$progress.find('.spinner').hide();
                return;
            }

            var id = ids.shift();

            $.get(
                ajaxurl,
                {
                    action: 'themejr_generate_image',
                    id: id,
                    _wpnonce: themejr.$importer.find('input[name="_wpnonce"]').val()
                },
                function (response) {
                    themejr.log(response.data + ' (' + ids.length + ' images left)');

                    themejr.generateSingleImage(ids);
                }
            );
        },

        log: function (message) {
            themejr.$progress.find('.text').text(message);
            themejr.$log.prepend('<p>' + message + '</p>');
        }
    };


    themejr.init();
});
