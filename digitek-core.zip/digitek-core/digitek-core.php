<?php
/*
Plugin Name: DigiTek Core
Plugin URI: https://themejr.com
Plugin URI: https://themeforest.net/user/themejr
Description: Extra Elementor elements for DigiTek Theme.
Version: 1.0.0
Author: ThemeJR
Author URI: https://themejr.com
Text Domain: digitek-core
*/

// don't load directly
if ( !defined( 'ABSPATH' ) ){
    die('-1');
}

if ( 'digitek' !== get_template() ) {
	return;
}

if( !defined( 'DIGITEK_CORE_VERSION' ) ) {
    define( 'DIGITEK_CORE_VERSION', '1.0.0' ); // Version of plugin
}

if( !defined( 'DIGITEK_CORE_DIR' ) ) {
    define( 'DIGITEK_CORE_DIR', dirname( __FILE__ ) ); // Plugin dir
}

if( !defined( 'DIGITEK_CORE_URL' ) ) {
    define( 'DIGITEK_CORE_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}

if( !defined( 'DIGITEK_PREFIX' ) ) {
	define('DIGITEK_PREFIX', '_jrth_');
}
		
// Load Custom Post types
require_once DIGITEK_CORE_DIR .'/posts/posts-content.php';

// Load Custom widget
require DIGITEK_CORE_DIR . '/widgets/init.php';

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

// Load plugin text domain
load_plugin_textdomain( 'digitek-core', false, plugin_basename( dirname( __FILE__ ) ) . "/languages" );

if ( !class_exists ( 'ReduxFramework' ) && file_exists ( DIGITEK_CORE_DIR.'/inc/admin/redux-core/framework.php' ) ) {
    require_once ( DIGITEK_CORE_DIR .'/inc/admin/redux-core/framework.php' );
} 

if ( !class_exists ( 'RWMB_Loader' ) && file_exists ( DIGITEK_CORE_DIR.'/inc/admin/meta-box/meta-box.php' ) ) {
    require_once ( DIGITEK_CORE_DIR.'/inc/admin/meta-box/meta-box.php' );
	require_once DIGITEK_CORE_DIR .'/inc/admin/custom-field-image-set.php';
} 

// Load Wordpress Importer plugin
require_once DIGITEK_CORE_DIR .'/inc/admin/class-admin.php';
require_once DIGITEK_CORE_DIR .'/inc/admin/class-white-label.php';

//Load functions
require_once DIGITEK_CORE_DIR .'/inc/functions.php';

/**
 * Init digitek elementor elements
 */
function digitek_init_elementor() {
	// Check if Elementor installed and activated
	if ( ! did_action( 'elementor/loaded' ) ) {
		return;
	}

	// Check for required Elementor version
	if ( ! version_compare( ELEMENTOR_VERSION, '2.0.0', '>=' ) ) {
		return;
	}

	// Check for required PHP version
	if ( version_compare( PHP_VERSION, '5.4', '<' ) ) {
		return;
	}

	// Once we get here, We have passed all validation checks so we can safely include our plugin
	include_once( DIGITEK_CORE_DIR . '/inc/elementor/elementor-functions.php' );
	include_once( DIGITEK_CORE_DIR . '/inc/elementor/class-elementor.php' );
}
add_action( 'plugins_loaded', 'digitek_init_elementor' );