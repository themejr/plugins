<?php
/**
 * Plugin Name: Techtec Addons
 * Plugin URI: http://techtec.themejr.com/
 * Description: elements for WPBakery Page Builder and Elementor.
 * Version: 1.0.0
 * Author: ThemeJR
 * Author URI: http://themejr.com/
 * License: GPL2+
 * Text Domain: techtec
 * Domain Path: /lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'TECHTEC_ADDONS_DIR' ) ) {
	define( 'TECHTEC_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'TECHTEC_ADDONS_URL' ) ) {
	define( 'TECHTEC_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once TECHTEC_ADDONS_DIR . '/inc/taxonomies.php';
require_once TECHTEC_ADDONS_DIR . '/inc/visual-composer.php';
require_once TECHTEC_ADDONS_DIR . '/inc/shortcodes.php';
require_once TECHTEC_ADDONS_DIR . '/inc/functions.php';
require_once TECHTEC_ADDONS_DIR . '/inc/widgets/widgets.php';

if ( is_admin() ) {
	require_once TECHTEC_ADDONS_DIR . '/inc/importer.php';
}

/**
 * Init
 */
function techtec_vc_addons_init() {
	load_plugin_textdomain( 'techtec', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );

	new Techtec_Taxonomies;
	new Techtec_VC;
	new Techtec_Shortcodes;

}

add_action( 'after_setup_theme', 'techtec_vc_addons_init', 30 );

function techtec_unregister_sidebar() {
	unregister_widget( 'WC_Widget_Layered_Nav' );
	unregister_widget( 'WC_Widget_Layered_Nav_Filters' );
	unregister_widget( 'WC_Widget_Rating_Filter' );
}

add_action( 'widgets_init', 'techtec_unregister_sidebar' );

/**
 * Undocumented function
 */
function techtec_init_elementor() {
	techtec_includes();
	spl_autoload_register( '\Techtec\Addons\Auto_Loader::load' );
	techtec_add_actions();

	// Check if Elementor installed and activated
	if ( ! did_action( 'elementor/loaded' ) ) {
		return;
	}

	// Check for required Elementor version
	if ( ! version_compare( ELEMENTOR_VERSION, '2.0.0', '>=' ) ) {
		return;
	}

	// Check for required PHP version
	if ( version_compare( PHP_VERSION, '5.4', '<' ) ) {
		return;
	}

	// Once we get here, We have passed all validation checks so we can safely include our plugin
	include_once( TECHTEC_ADDONS_DIR . 'inc/elementor-autoloader.php' );
	include_once( TECHTEC_ADDONS_DIR . 'inc/elementor.php' );
	include_once( TECHTEC_ADDONS_DIR . 'inc/elementor-ajaxloader.php' );
}

add_action( 'plugins_loaded', 'techtec_init_elementor' );

/**
 * Includes files
 *
 * @since 1.0.0
 *
 * @return void
 */
function techtec_includes() {
	// Auto Loader
	require_once TECHTEC_ADDONS_DIR . 'inc/elementor-autoloader.php';
	\Techtec\Addons\Auto_Loader::register( [
		'Techtec\Addons\Modules'        => TECHTEC_ADDONS_DIR . 'modules/modules.php',
	] );
}

/**
 * Add Actions
 *
 * @since 1.0.0
 *
 * @return void
 */
function techtec_add_actions() {
	// Before init action.
	do_action( 'before_techtec_init' );

	// Modules
	techtec_get( 'modules' );

	// Init action.
	do_action( 'after_techtec_init' );
}

/**
 * Get Techtec Addons Class instance
 *
 * @since 1.0.0
 *
 * @return object
 */
function techtec_get( $class ) {
	switch ( $class ) {
		case 'modules':
			return \Techtec\Addons\Modules::instance();
			break;
	}
}