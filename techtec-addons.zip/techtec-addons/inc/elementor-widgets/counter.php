<?php

namespace TechtecAddons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Icon Box widget
 */
class Counter extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'techtec-counter';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Techtec - Counter', 'techtec' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter-circle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'techtec' ];
	}

	public function get_script_depends() {
		return [
			'techtec-elementor'
		];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_icon',
			[ 'label' => esc_html__( 'Icons', 'techtec' ) ]
		);

		$this->add_control(
			'icon_type',
			[
				'label'   => esc_html__( 'Icon Type', 'techtec' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'icon'        => esc_html__( 'Old Icon', 'techtec' ),
					'image'       => esc_html__( 'Image', 'techtec' ),
					'custom_icon' => esc_html__( 'New Icon', 'techtec' ),
				],
				'default' => 'icon',
				'toggle'  => false,
			]
		);

		$this->add_control(
			'icon',
			[
				'label'     => esc_html__( 'Icon', 'techtec' ),
				'type'      => Controls_Manager::ICON,
				'default'   => 'icon-cube',
				'condition' => [
					'icon_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label'     => esc_html__( 'Choose Image', 'techtec' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'icon_type' => 'image',
				],
			]
		);

		$this->add_control(
			'custom_icon',
			[
				'label'     => esc_html__( 'Icon', 'techtec' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'condition' => [
					'icon_type' => 'custom_icon',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image',
				// Usage: `{name}_size` and `{name}_custom_dimension`, in this case `image_size` and `image_custom_dimension`.
				'default'   => 'large',
				'separator' => 'none',
				'condition' => [
					'icon_type' => 'image',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content',
			[ 'label' => esc_html__( 'Content', 'techtec' ) ]
		);
		$this->add_control(
			'value', [
				'label'       => esc_html__( 'Value', 'techtec' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '1.8',
				'description' => esc_html__( 'Input integer value for counting', 'techtec' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'unit_before', [
				'label'       => esc_html__( 'Unit Before', 'techtec' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => esc_html__( 'Enter the Unit. Example: +, % .etc', 'techtec' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'unit_after', [
				'label'       => esc_html__( 'Unit After', 'techtec' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'M',
				'description' => esc_html__( 'Enter the Unit. Example: +, % .etc', 'techtec' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'techtec' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Products for sale', 'techtec' ),
				'placeholder' => esc_html__( 'Enter the title', 'techtec' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		/**
		 * Tab Style
		 */
		// Icon
		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => esc_html__( 'Icon/Image', 'techtec' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'icon_position',
			[
				'label'   => esc_html__( 'Position', 'techtec' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'left'   => esc_html__( 'Left', 'techtec' ),
					'right'  => esc_html__( 'Right', 'techtec' ),
					'center' => esc_html__( 'Top Center', 'techtec' ),
				],
				'default' => 'center',
				'toggle'  => false,
			]
		);
		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'techtec' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 28,
				],
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els.tech-icon--left .tech-icon'   => 'padding-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .techtec-counter-els.tech-icon--left .tech-img'    => 'padding-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .techtec-counter-els.tech-icon--right .tech-icon'  => 'padding-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .techtec-counter-els.tech-icon--right .tech-img'   => 'padding-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .techtec-counter-els.tech-icon--center .tech-icon' => 'padding-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .techtec-counter-els.tech-icon--center .tech-img'  => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_font_size',
			[
				'label'     => esc_html__( 'Icon Font Size', 'techtec' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 72,
				],
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .tech-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_type' => ['icon', 'custom_icon'],
				],
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'techtec' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgb(252,184,0)',
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .tech-icon'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .techtec-counter-els .tech-icon svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'icon_type' => ['icon', 'custom_icon'],
				],
			]
		);

		$this->end_controls_section();

		// Value
		$this->start_controls_section(
			'section_item_style',
			[
				'label' => esc_html__( 'Value', 'techtec' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'value_typography',
				'selector' => '{{WRAPPER}} .techtec-counter-els .counter',
			]
		);
		$this->add_control(
			'value_color',
			[
				'label'     => esc_html__( 'Color', 'techtec' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .counter' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'value_spacing',
			[
				'label'     => esc_html__( 'Bottom Spacing', 'techtec' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'default'   => [
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .counter' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'separator_1',
			[
				'label'     => esc_html__( 'Unit Before', 'techtec' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'before_font_size',
			[
				'label'     => esc_html__( 'Font Size', 'techtec' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'default'   => [],
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .counter .unit-before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'before_color',
			[
				'label'     => esc_html__( 'Color', 'techtec' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .counter .unit-before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'separator_2',
			[
				'label'     => esc_html__( 'Unit After', 'techtec' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'after_font_size',
			[
				'label'     => esc_html__( 'Font Size', 'techtec' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'default'   => [],
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .counter .unit-after' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'after_color',
			[
				'label'     => esc_html__( 'Color', 'techtec' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els .counter .unit-after' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		// Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'techtec' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .techtec-counter-els h4',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'techtec' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .techtec-counter-els h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'wrapper', 'class', [
				'techtec-counter-els',
				'tech-icon--' . $settings['icon_position'],
			]
		);

		$icon = $output = $unit_before = $unit_after = '';

		if ( $settings['icon_type'] == 'image' ) {
			if ( $settings['image'] ) {
				$icon = '<div class="tech-img">' . Group_Control_Image_Size::get_attachment_image_html( $settings ) . '</div>';
			}
		} elseif ( $settings['icon_type'] == 'icon' ) {
			$icon = '<span class="tech-icon"><i class="' . esc_attr( $settings['icon'] ) . '"></i></span>';
		} else {
			if ( $settings['custom_icon'] && \Elementor\Icons_Manager::is_migration_allowed() ) {
				ob_start();
				\Elementor\Icons_Manager::render_icon( $settings['custom_icon'], [ 'aria-hidden' => 'true' ] );
				$icon = '<span class="tech-icon">' . ob_get_clean() . '</span>';
			}
		}

		if ( $settings['unit_before'] ) {
			$unit_before = sprintf( '<span class="unit unit-before">%s</span>', $settings['unit_before'] );
		}

		if ( $settings['unit_after'] ) {
			$unit_after = sprintf( '<span class="unit unit-after">%s</span>', $settings['unit_after'] );
		}

		if ( $settings['value'] ) {
			$output = sprintf( '<div class="counter">%s<span class="counter-value">%s</span>%s</div>', $unit_before, $settings['value'], $unit_after );
		}

		if ( $settings['title'] ) {
			$output .= sprintf( '<h4 class="title">%s</h4>', $settings['title'] );
		}

		echo sprintf(
			'<div %s>%s<div class="counter-content">%s</div></div>',
			$this->get_render_attribute_string( 'wrapper' ),
			$icon,
			$output
		);

	}

}