<?php
/**
 * Hooks for importer
 *
 * @package Techtec
 */


/**
 * Importer the demo content
 *
 * @since  1.0
 *
 */
function techtec_vc_addons_importer() {
	return array(
		array(
			'name'       => 'WPBakery - Auto Parts',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '0',
			'pages'      => array(
				'front_page' => 'HomePage',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'WPBakery - Full Width',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '0',
			'pages'      => array(
				'front_page' => 'Home Full Width',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'WPBakery - Technology',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '0',
			'pages'      => array(
				'front_page' => 'Home',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'WPBakery - Organic',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '0',
			'pages'      => array(
				'front_page' => 'Home',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'WPBakery - Marketplace V1',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '0',
			'pages'      => array(
				'front_page' => 'Home',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),



		// Elementor
		array(
			'name'       => 'Elementor - Medical',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '1',
			'pages'      => array(
				'front_page' => 'HomePage',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Elementor - Kids',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '1',
			'pages'      => array(
				'front_page' => 'HomePage',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Elementor - Kids With AJAX',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '1',
			'pages'      => array(
				'front_page' => 'Home With Ajax',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Elementor - Auto Parts',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '1',
			'pages'      => array(
				'front_page' => 'HomePage',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Elementor - Full Width',
			'preview'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.jpg',
			'content'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1.xml',
			'customizer' => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-customizer.dat',
			'widgets'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-widgets.wie',
			'sliders'    => 'https://github.com/themejr/plugins/raw/techtec/techtec-home1-sliders.zip',
			'tab'        => '1',
			'pages'      => array(
				'front_page' => 'Home Full Width',
				'blog'       => 'Our Press',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary'         => 'primary-menu',
				'shop_department' => 'shop-by-department',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 480,
					'height' => 480,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 600,
					'height' => 600,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
	);
}

add_filter( 'jrth_demo_packages', 'techtec_vc_addons_importer', 20 );


/**
 * Prepare product attributes before import demo content
 *
 * @param $file
 */
function techtec_addons_import_product_attributes( $file ) {
	global $wpdb;

	if ( ! class_exists( 'WXR_Parser' ) ) {
		require_once WP_PLUGIN_DIR . '/jrth-demo-importer/includes/parsers.php';
	}

	$parser      = new WXR_Parser();
	$import_data = $parser->parse( $file );

	if ( isset( $import_data['posts'] ) ) {
		$posts = $import_data['posts'];

		if ( $posts && sizeof( $posts ) > 0 ) {
			foreach ( $posts as $post ) {
				if ( 'product' === $post['post_type'] ) {
					if ( ! empty( $post['terms'] ) ) {
						foreach ( $post['terms'] as $term ) {
							if ( strstr( $term['domain'], 'pa_' ) ) {
								if ( ! taxonomy_exists( $term['domain'] ) ) {
									$attribute_name = wc_sanitize_taxonomy_name( str_replace( 'pa_', '', $term['domain'] ) );

									// Create the taxonomy
									if ( ! in_array( $attribute_name, wc_get_attribute_taxonomies() ) ) {
										$attribute = array(
											'attribute_label'   => $attribute_name,
											'attribute_name'    => $attribute_name,
											'attribute_type'    => 'select',
											'attribute_orderby' => 'menu_order',
											'attribute_public'  => 0,
										);
										$wpdb->insert( $wpdb->prefix . 'woocommerce_attribute_taxonomies', $attribute );
										delete_transient( 'wc_attribute_taxonomies' );
									}

									// Register the taxonomy now so that the import works!
									register_taxonomy(
										$term['domain'],
										apply_filters( 'woocommerce_taxonomy_objects_' . $term['domain'], array( 'product' ) ),
										apply_filters(
											'woocommerce_taxonomy_args_' . $term['domain'], array(
												'hierarchical' => true,
												'show_ui'      => false,
												'query_var'    => true,
												'rewrite'      => false,
											)
										)
									);
								}
							}
						}
					}
				}
			}
		}
	}
}

add_action( 'themejr_before_import_content', 'techtec_addons_import_product_attributes' );