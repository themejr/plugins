(function ($) {
    'use strict';
    var techtec = techtec || {};

    techtec.found_data = false;
    techtec.variation_id = 0;

    techtec.foundVariationImages = function( ) {
        $( '.variations_form:not(.form-cart-pbt)' ).on('found_variation', function(e, $variation){
            if( techtec.variation_id != $variation.variation_id ) {
                techtec.changeVariationImagesAjax($variation.variation_id, $(this).data('product_id'));
                techtec.found_data = true;
                techtec.variation_id = $variation.variation_id;
            }
        });
    }

    techtec.resetVariationImages = function( ) {
        $( '.variations_form:not(.form-cart-pbt)' ).on('reset_data', function(e){
            if( techtec.found_data ) {
                techtec.changeVariationImagesAjax(0, $(this).data('product_id'));
                techtec.found_data = false;
                techtec.variation_id = 0;
            }

        });
    }

    techtec.changeVariationImagesAjax = function(variation_id, product_id) {
        var $productGallery = $('.woocommerce-product-gallery'),
            galleryHeight = $productGallery.height();
            $productGallery.addClass('loading').css( {'overflow': 'hidden' });
            if( ! $productGallery.closest('.single-product').hasClass('quick-view-modal') ) {
                $productGallery.css( {'height': galleryHeight });
            }

        var data = {
            'variation_id': variation_id,
            'product_id': product_id,
            nonce: techtecData.nonce,
        },
        ajax_url = techtecData.wc_ajax_url.toString().replace('%%endpoint%%', 'techtec_get_variation_images');

        var xhr = $.post(
            ajax_url,
            data,
            function (response) {
                var $gallery = $(response.data);

                $productGallery.html( $gallery.html() );
                if ( typeof wc_single_product_params !== 'undefined' && $.fn.wc_product_gallery) {
                    $productGallery.removeData('flexslider');
                    $productGallery.off('click', '.woocommerce-product-gallery__image a');
                    $productGallery.off('click', '.woocommerce-product-gallery__trigger');
                    $productGallery.wc_product_gallery( wc_single_product_params );
                    $productGallery.trigger('product_thumbnails_slider');
                    $productGallery.trigger('product_video_slider');
                    $productGallery.trigger('product_gallery');
                    $productGallery.find('img.lazy').lazyload().trigger('appear');
                }
                $productGallery.trigger('techtec_update_product_gallery_on_quickview');

                $productGallery.imagesLoaded(function () {
                    setTimeout(function() {
                        $productGallery.removeClass('loading').removeAttr( 'style' ).css('opacity', '1');
                    }, 200);
                    $productGallery.trigger( 'techtec_gallery_init_zoom', $productGallery.find('.woocommerce-product-gallery__image').first());
                } );

            }
        );
    }
    /**
     * Document ready
     */
    $(function () {
        if( $('div.product' ).hasClass('product-has-variation-images') ) {
            techtec.foundVariationImages();
            techtec.resetVariationImages();
        }

        $('body').on( 'techtec_product_quick_view_loaded', function() {
            if( $('div.product' ).hasClass('product-has-variation-images') ) {
                techtec.foundVariationImages();
                techtec.resetVariationImages();
            }
        } );
    });

})(jQuery);