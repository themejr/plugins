<?php
/**
 * Plugin's main class
 */
class WOOC_Deals {
	/**
	 * The single instance of the class
	 *
	 * @var WOOC_Deals
	 */
	protected static $instance = null;

	/**
	 * Extra attribute types
	 *
	 * @var array
	 */
	public $types = array();

	/**
	 * Main instance
	 *
	 * @return WOOC_Deals
	 */
	public static function instance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Include required core files used in admin and on the frontend.
	 */
	public function includes() {
		require_once dirname( __FILE__ ) . '/deal-functions.php';
		require_once dirname( __FILE__ ) . '/class-frontend.php';
		require_once dirname( __FILE__ ) . '/class-shortcodes.php';
		require_once dirname( __FILE__ ) . '/class-admin.php';
	}

	/**
	 * Initialize hooks
	 */
	public function init_hooks() {
		add_action( 'init', array( $this, 'load_textdomain' ) );
		add_action( 'init', array( 'WOOC_Deals_Frontend', 'instance' ) );
		add_action( 'init', array( 'WOOC_Deals_Shortcodes', 'init' ) );
	}

	/**
	 * Load plugin text domain
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'wooc-deals', false, dirname( plugin_basename( WOOC_DEALS_PLUGIN_FILE ) ) . '/languages/' );
	}
}